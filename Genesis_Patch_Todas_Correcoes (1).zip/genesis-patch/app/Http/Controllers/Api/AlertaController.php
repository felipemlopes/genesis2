<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Alerta;
use Bavix\Wallet\Models\Transaction;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

class AlertaController extends Controller
{
    public function index()
    {
        $items = Alerta::orderBy('created_at', 'desc')
            ->limit(100)
            ->get();

        return response()->json(['success' => true, 'data' => $items]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'ativo' => 'required|string|max:20',
            'tipo' => 'required|string|max:50',
            'mensagem' => 'required|string',
            'direcao' => 'required|in:BULLISH,BEARISH,NEUTRO',
            'urgencia' => 'required|in:ALTA,MEDIA,BAIXA',
            'corretora' => 'required|string|max:20',
            'timeframe' => 'nullable|string|max:10',
            'preco_atual' => 'required|numeric',
            'variacao_pct' => 'required|numeric',
            'score' => 'nullable|integer|min:0|max:100',
        ]);

        $item = Alerta::create($request->all());

        return response()->json(['success' => true, 'data' => $item], 201);
    }

    public function show(string $id)
    {
        $item = Alerta::findOrFail($id);

        return response()->json(['success' => true, 'data' => $item]);
    }

    public function destroy(string $id)
    {
        $item = Alerta::findOrFail($id);
        $item->delete();

        return response()->json(['message' => 'Removido com sucesso']);
    }

    /**
     * Polling endpoint - retorna alertas recentes para o usuario autenticado.
     * Campos sensíveis (ativo, corretora, preco_atual) só são incluídos
     * se o alerta foi revelado pelo usuário autenticado.
     */
    public function poll()
    {
        $user = auth()->user();

        if (!$user) {
            return response()->json(['success' => false, 'message' => 'Unauthenticated'], 401);
        }

        $alertas = Alerta::where('created_at', '>=', now()->subHours(24))
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

        // Aplica paywall: omite ativo/corretora/preco_atual se não revelado pelo user
        $data = $alertas->map(function ($alerta) use ($user) {
            $item = [
                'id' => $alerta->id,
                'tipo' => $alerta->tipo,
                'direcao' => $alerta->direcao,
                'score' => $alerta->score,
                'motivos' => $alerta->motivos,
                'timeframes' => $alerta->timeframes,
                'urgencia' => $alerta->urgencia,
                'mensagem' => $alerta->mensagem,
                'criado_em' => $alerta->created_at->toISOString(),
                'expires_at' => $alerta->expires_at,
            ];

            // Inclui campos protegidos apenas se revelado pelo usuário autenticado
            if ((int) $alerta->revelado_por === (int) $user->id) {
                $item['ativo'] = $alerta->ativo;
                $item['corretora'] = $alerta->corretora;
                $item['preco_atual'] = $alerta->preco_atual;
            }

            return $item;
        });

        return response()->json(['success' => true, 'data' => $data]);
    }

    /**
     * Reveal de alerta — debita créditos conforme setting cost_micro_radar_credits (padrão 50).
     * Usa idempotency_key para evitar cobrança duplicada em retries.
     * Se o mesmo idempotency_key já foi usado para este alert+user, retorna
     * os dados existentes sem debitar novamente.
     */
    public function reveal(string $id, Request $request)
    {
        $request->validate([
            'idempotency_key' => 'required|string|max:100',
        ]);

        $alerta = Alerta::findOrFail($id);
        $user = auth()->user();
        $idempotencyKey = $request->input('idempotency_key');

        // Idempotência: se já existe transação com essa key para este user+alerta, retorna sem debitar
        $existing = Transaction::where('payable_id', $user->id)
            ->where('payable_type', get_class($user))
            ->where('meta->idempotency_key', $idempotencyKey)
            ->where('meta->alerta_id', (int) $id)
            ->first();

        if ($existing) {
            // Garante que o alerta está marcado como revelado pelo user
            if ((int) $alerta->revelado_por !== (int) $user->id) {
                $alerta->update([
                    'revelado_por' => $user->id,
                    'revelado_em' => now(),
                ]);
            }

            return response()->json([
                'success' => true,
                'data' => [
                    'ativo' => $alerta->ativo,
                    'corretora' => $alerta->corretora,
                    'preco_atual' => $alerta->preco_atual,
                    'timeframes' => $alerta->timeframes,
                    'credits_remaining' => (float) $user->balanceFloat,
                ],
            ]);
        }

        // Se o alerta já foi revelado por este mesmo user (key diferente), retorna sem debitar
        if ((int) $alerta->revelado_por === (int) $user->id) {
            return response()->json([
                'success' => true,
                'data' => [
                    'ativo' => $alerta->ativo,
                    'corretora' => $alerta->corretora,
                    'preco_atual' => $alerta->preco_atual,
                    'timeframes' => $alerta->timeframes,
                    'credits_remaining' => (float) $user->balanceFloat,
                ],
            ]);
        }

        // Verifica saldo suficiente
        $custReveal = (float) setting('cost_micro_radar_credits', 50);
        if ($user->balanceFloat < $custReveal) {
            return response()->json([
                'success' => false,
                'error' => 'Créditos insuficientes',
            ], 422);
        }

        // Debita créditos via setting (configurável no painel)
        $user->withdrawFloat($custReveal, [
            'description' => 'Micro Radar Reveal',
            'idempotency_key' => $idempotencyKey,
            'alerta_id' => (int) $id,
        ]);

        // Marca alerta como revelado
        $alerta->update([
            'revelado_por' => $user->id,
            'revelado_em' => now(),
        ]);

        return response()->json([
            'success' => true,
            'data' => [
                'ativo' => $alerta->ativo,
                'corretora' => $alerta->corretora,
                'preco_atual' => $alerta->preco_atual,
                'timeframes' => $alerta->timeframes,
                'credits_remaining' => (float) $user->balanceFloat,
            ],
        ]);
    }

    public function stream(): StreamedResponse
    {
        // Remove o limite de execução para SSE (necessário para conexões longas)
        set_time_limit(0);
        ini_set('max_execution_time', '0');

        // Desabilita output buffering do PHP para flush imediato
        if (ob_get_level()) {
            ob_end_clean();
        }

        return new StreamedResponse(function () {
            $lastPing = time();
            $startTime = time();
            $maxLifetime = 120; // Máximo 2 minutos por conexão — frontend reconecta automaticamente

            while (true) {
                // Limite de vida da conexão para não prender thread do Apache
                if ((time() - $startTime) >= $maxLifetime) {
                    echo "data: {\"_reconnect\": true}\n\n";
                    flush();
                    break;
                }

                // Poll for unsent alerts
                $alertas = Alerta::where('enviado_sse', 0)
                    ->orderBy('created_at', 'asc')
                    ->limit(50)
                    ->get();

                foreach ($alertas as $alerta) {
                    $payload = $alerta->toArray();
                    unset($payload['direcao'], $payload['urgencia']);

                    echo "data: " . json_encode($payload) . "\n\n";
                    flush();

                    $alerta->update(['enviado_sse' => 1]);
                }

                // Ping a cada 25 segundos para manter conexão viva
                if (time() - $lastPing >= 25) {
                    echo "data: ping\n\n";
                    flush();
                    $lastPing = time();
                }

                // Cliente desconectou
                if (connection_aborted()) {
                    break;
                }

                // Sleep curto para não sobrecarregar CPU
                usleep(3000000); // 3 segundos
            }
        }, 200, [
            'Content-Type' => 'text/event-stream',
            'Cache-Control' => 'no-cache, no-store, must-revalidate',
            'Connection' => 'keep-alive',
            'X-Accel-Buffering' => 'no',
            'Access-Control-Allow-Origin' => '*',
        ]);
    }
}
