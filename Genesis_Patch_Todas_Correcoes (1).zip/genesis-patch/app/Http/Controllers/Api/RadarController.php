<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Alerta;
use App\Models\UserRevelacao;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class RadarController extends Controller
{
    /**
     * GET /api/v1/radar/alertas
     * Retorna último alerta OPORTUNIDADE não revelado pelo membro.
     * Omite: ativo, corretora, timeframe, direcao.
     */
    public function alertas(Request $request): JsonResponse
    {
        $user = $request->user();
        $revelados = UserRevelacao::where('user_id', $user->id)->pluck('alerta_id');

        $alerta = Alerta::where('tipo', 'OPORTUNIDADE')
            ->where('score', '>=', 65)
            ->whereNotIn('id', $revelados)
            ->orderByDesc('created_at')
            ->first(['id', 'tipo', 'urgencia', 'created_at']); // NÃO incluir ativo/corretora/timeframe aqui

        if (!$alerta) {
            return response()->json(['success' => true, 'data' => null]);
        }

        return response()->json([
            'success' => true,
            'data' => [
                'id' => $alerta->id,
                'tipo' => $alerta->tipo,
                'urgencia' => $alerta->urgencia,
                'criado_em' => $alerta->created_at,
                'status' => 'pendente',
            ],
        ]);
    }

    /**
     * POST /api/v1/radar/revelar/{id}
     * Debita 50 créditos e revela ativo, corretora, timeframe.
     * Idempotente: se já revelado, retorna sem debitar.
     */
    public function revelar(string $id, Request $request): JsonResponse
    {
        $user = $request->user();
        $alerta = Alerta::findOrFail($id);

        // Idempotência: se já revelado, retornar sem debitar
        $existente = UserRevelacao::where('user_id', $user->id)
            ->where('alerta_id', $id)
            ->first();

        if ($existente) {
            return response()->json([
                'success' => true,
                'data' => [
                    'ativo' => $alerta->ativo,
                    'corretora' => $alerta->corretora,
                    'timeframe' => $alerta->timeframe,
                ],
            ]);
        }

        // Verificar saldo
        // Fluxo: membro vê 'Oportunidade encontrada' (grátis)
        // → clica Analisar → paga aqui (50 créditos) → descobre par + corretora
        // → vai para tela de análise com par pré-preenchido → paga 100 créditos na análise
        $custo = (float) setting('cost_micro_radar_credits', 50);
        if ($user->balanceFloat < $custo) {
            return response()->json([
                'success' => false,
                'message' => 'Créditos insuficientes',
            ], 402);
        }

        // Debitar créditos
        $user->withdrawFloat($custo, ['description' => 'Micro Radar - Revelação']);

        // Registrar revelação
        UserRevelacao::create([
            'user_id' => $user->id,
            'alerta_id' => $id,
            'revelado_em' => now(),
        ]);

        return response()->json([
            'success' => true,
            'data' => [
                'ativo' => $alerta->ativo,
                'corretora' => $alerta->corretora,
                'timeframe' => $alerta->timeframe,
            ],
        ]);
    }

    /**
     * GET /api/v1/radar/historico
     * Últimos 50 alertas revelados pelo membro, ordenados por revelado_em DESC.
     * Omite direcao.
     */
    public function historico(Request $request): JsonResponse
    {
        $user = $request->user();

        $historico = UserRevelacao::where('user_id', $user->id)
            ->with('alerta:id,ativo,corretora,timeframe,created_at')
            ->orderByDesc('revelado_em')
            ->limit(50)
            ->get()
            ->map(fn ($r) => [
                'id' => $r->alerta_id,
                'ativo' => $r->alerta->ativo,
                'corretora' => $r->alerta->corretora,
                'timeframe' => $r->alerta->timeframe,
                'criado_em' => $r->alerta->created_at,
                'revelado_em' => $r->revelado_em,
            ]);

        return response()->json(['success' => true, 'data' => $historico]);
    }
}
