<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;

class TechnicalAnalysisService
{
    public function calcular(array $candles, array $ocrData = []): array
    {
        $closes = [];
        $highs = [];
        $lows = [];
        $volumes = [];

        foreach ($candles as $c) {
            if (is_array($c) && count($c) >= 6) {
                $closes[] = (float) $c[4];
                $highs[] = (float) $c[2];
                $lows[] = (float) $c[3];
                $volumes[] = (float) $c[5];
            }
        }

        $preco = !empty($closes) ? end($closes) : 0;

        // EMA 21
        $ema21_fonte = "INDISPONIVEL";
        try { $ema21 = $this->ema($closes, 21); } catch (\Throwable $e) { $ema21 = null; }
        if ($ema21 !== null) { $ema21_fonte = "API"; }
        elseif (isset($ocrData["ema_21"])) { $ema21 = (float) $ocrData["ema_21"]; $ema21_fonte = "OCR"; }

        // EMA 50
        $ema50_fonte = "INDISPONIVEL";
        try { $ema50 = $this->ema($closes, 50); } catch (\Throwable $e) { $ema50 = null; }
        if ($ema50 !== null) { $ema50_fonte = "API"; }
        elseif (isset($ocrData["ema_50"])) { $ema50 = (float) $ocrData["ema_50"]; $ema50_fonte = "OCR"; }

        // EMA 200
        $ema200_fonte = "INDISPONIVEL";
        try { $ema200 = $this->ema($closes, 200); } catch (\Throwable $e) { $ema200 = null; }
        if ($ema200 !== null) { $ema200_fonte = "API"; }
        elseif (isset($ocrData["ema_200"])) { $ema200 = (float) $ocrData["ema_200"]; $ema200_fonte = "OCR"; }

        // Prev EMAs (para direcao)
        try { $prevEma21 = $this->ema(array_slice($closes, 0, -1), 21); } catch (\Throwable $e) { $prevEma21 = null; }
        try { $prevEma50 = $this->ema(array_slice($closes, 0, -1), 50); } catch (\Throwable $e) { $prevEma50 = null; }
        try { $prevEma200 = $this->ema(array_slice($closes, 0, -1), 200); } catch (\Throwable $e) { $prevEma200 = null; }

        // RSI
        $rsi_fonte = "INDISPONIVEL";
        try { $rsi = $this->rsi($closes, 14); } catch (\Throwable $e) { $rsi = null; }
        if ($rsi !== null) { $rsi_fonte = "API"; }
        elseif (isset($ocrData["rsi"])) { $rsi = (float) $ocrData["rsi"]; $rsi_fonte = "GRAFICO"; }

        // ADX
        $adx_fonte = "INDISPONIVEL";
        $adxResult = null;
        try { $adxResult = $this->adx($highs, $lows, $closes, 14); } catch (\Throwable $e) { $adxResult = null; }
        if ($adxResult !== null) { $adx_fonte = "API"; }
        elseif (isset($ocrData["adx"])) {
            $adxResult = ["adx" => (float) $ocrData["adx"], "plus_di" => 0, "minus_di" => 0, "adx_subindo" => false];
            $adx_fonte = "GRAFICO";
        }

        // MACD
        $macd_fonte = "INDISPONIVEL";
        $macdResult = null;
        try { $macdResult = $this->macd($closes); } catch (\Throwable $e) { $macdResult = null; }
        $prevMacdResult = null;
        try { $prevMacdResult = $this->macd(array_slice($closes, 0, -1)); } catch (\Throwable $e) { $prevMacdResult = null; }
        if ($macdResult !== null) { $macd_fonte = "API"; }
        elseif (isset($ocrData["macd"])) {
            $macdResult = ["macd" => (float) $ocrData["macd"], "signal" => 0, "histogram" => (float) $ocrData["macd"]];
            $macd_fonte = "GRAFICO";
        }

        // ATR
        $atr_fonte = "INDISPONIVEL";
        try { $atr = $this->atr($highs, $lows, $closes, 14); } catch (\Throwable $e) { $atr = null; }
        if ($atr !== null) { $atr_fonte = "API"; }
        elseif (isset($ocrData["atr"])) { $atr = (float) $ocrData["atr"]; $atr_fonte = "GRAFICO"; }

        // Bollinger
        try { $bollinger = $this->bollinger($closes, 20, 2.0); } catch (\Throwable $e) { $bollinger = null; }

        // Compressao
        try { $compressao = $this->detectarCompressao($closes, $volumes); } catch (\Throwable $e) { $compressao = ["detectada" => false, "nivel" => "NENHUMA", "volume_decrescente" => false, "probabilidade" => 0]; }

        // Divergencia RSI
        try { $divergenciaRSI = $this->detectarDivergenciaRSI($closes, $rsi); } catch (\Throwable $e) { $divergenciaRSI = "NENHUMA"; }

        // Volume Analysis
        try {
            $volumeAnalise = $this->analisarVolume($candles);
        } catch (\Throwable $e) {
            $volumeAnalise = ['tendencia' => 'INDISPONIVEL', 'divergencia' => 'NENHUMA', 'ratio_atual' => 0, 'vol5' => 0, 'vol20' => 0];
        }

        // LOG DEBUG: EMAs e indicadores detalhados
        Log::info("DEBUG_TECH_ANALYSIS: Indicadores calculados", [
            "candles_count" => count($candles),
            "closes_count" => count($closes),
            "preco" => $preco,
            "ema21" => $ema21,
            "ema21_fonte" => $ema21_fonte,
            "ema21_prevEma" => $prevEma21,
            "ema50" => $ema50,
            "ema50_fonte" => $ema50_fonte,
            "ema50_prevEma" => $prevEma50,
            "ema200" => $ema200,
            "ema200_fonte" => $ema200_fonte,
            "ema200_prevEma" => $prevEma200,
            "rsi" => $rsi,
            "rsi_fonte" => $rsi_fonte,
            "adx" => $adxResult["adx"] ?? null,
            "adx_fonte" => $adx_fonte,
            "plus_di" => $adxResult["plus_di"] ?? null,
            "minus_di" => $adxResult["minus_di"] ?? null,
            "macd" => $macdResult["macd"] ?? null,
            "macd_signal" => $macdResult["signal"] ?? null,
            "macd_histograma" => $macdResult["histogram"] ?? null,
            "macd_fonte" => $macd_fonte,
            "atr" => $atr,
            "atr_fonte" => $atr_fonte,
            "bollinger" => $bollinger,
            "compressao" => $compressao,
            "divergencia_rsi" => $divergenciaRSI,
        ]);

        return [
            "preco" => $preco,
            "ema21" => $ema21,
            "ema50" => $ema50,
            "ema200" => $ema200,
            "ema21_subindo" => $ema21 !== null && $prevEma21 !== null ? $ema21 > $prevEma21 : false,
            "ema50_subindo" => $ema50 !== null && $prevEma50 !== null ? $ema50 > $prevEma50 : false,
            "ema200_subindo" => $ema200 !== null && $prevEma200 !== null ? $ema200 > $prevEma200 : false,
            "rsi" => $rsi,
            "divergencia_rsi" => $divergenciaRSI,
            "adx" => $adxResult["adx"] ?? null,
            "plus_di" => $adxResult["plus_di"] ?? null,
            "minus_di" => $adxResult["minus_di"] ?? null,
            "adx_subindo" => $adxResult["adx_subindo"] ?? false,
            "macd" => $macdResult["macd"] ?? null,
            "macd_signal" => $macdResult["signal"] ?? null,
            "macd_histograma" => $macdResult["histogram"] ?? null,
            "macd_acima_signal" => ($macdResult["macd"] ?? 0) > ($macdResult["signal"] ?? 0),
            "histograma_subindo" => ($macdResult["histogram"] ?? 0) > ($prevMacdResult["histogram"] ?? 0),
            "macd_cruza_zero" => $this->detectarMacdZeroCross($macdResult, $prevMacdResult),
            "atr" => $atr,
            "bollinger" => $bollinger,
            "compressao" => $compressao,
            "volume" => $volumeAnalise,
            "preco_subindo" => ($ema21 !== null && $prevEma21 !== null)
                ? $ema21 > $prevEma21
                : (count($closes) >= 2 ? $closes[count($closes) - 1] > $closes[count($closes) - 2] : false),
            "fontes" => [
                "ema21" => $ema21_fonte,
                "ema50" => $ema50_fonte,
                "ema200" => $ema200_fonte,
                "rsi" => $rsi_fonte,
                "adx" => $adx_fonte,
                "macd" => $macd_fonte,
                "atr" => $atr_fonte,
            ],
        ];
    }

    public function ema(array $closes, int $period): ?float
    {
        // Threshold corrigido: period + 1 (minimo matematico real)
        if (count($closes) < $period + 1) return null;
        $k = 2.0 / ($period + 1);
        $ema = array_sum(array_slice($closes, 0, $period)) / $period;
        for ($i = $period; $i < count($closes); $i++) {
            $ema = ($closes[$i] - $ema) * $k + $ema;
        }
        return is_finite($ema) && $ema > 0 ? $ema : null;
    }

    public function rsi(array $closes, int $period = 14): ?float
    {
        if (count($closes) <= $period) return null;
        $gains = 0;
        $losses = 0;
        for ($i = 1; $i <= $period; $i++) {
            $diff = $closes[$i] - $closes[$i - 1];
            if ($diff > 0) $gains += $diff;
            else $losses -= $diff;
        }
        $avgGain = $gains / $period;
        $avgLoss = $losses / $period;
        for ($i = $period + 1; $i < count($closes); $i++) {
            $diff = $closes[$i] - $closes[$i - 1];
            if ($diff > 0) {
                $avgGain = ($avgGain * ($period - 1) + $diff) / $period;
                $avgLoss = ($avgLoss * ($period - 1)) / $period;
            } else {
                $avgGain = ($avgGain * ($period - 1)) / $period;
                $avgLoss = ($avgLoss * ($period - 1) - $diff) / $period;
            }
        }
        if ($avgLoss === 0) return 100.0;
        $rs = $avgGain / $avgLoss;
        $rsi = 100 - (100 / (1 + $rs));
        return is_finite($rsi) ? round($rsi, 2) : null;
    }

    private function adx(array $highs, array $lows, array $closes, int $period = 14): ?array
    {
        $count = count($closes);
        if ($count < $period * 2 + 1) return null;

        $plusDM = [];
        $minusDM = [];
        $trArr = [];

        for ($i = 1; $i < $count; $i++) {
            $highDiff = $highs[$i] - $highs[$i - 1];
            $lowDiff = $lows[$i - 1] - $lows[$i];
            $plusDM[] = ($highDiff > $lowDiff && $highDiff > 0) ? $highDiff : 0;
            $minusDM[] = ($lowDiff > $highDiff && $lowDiff > 0) ? $lowDiff : 0;
            $tr = max(
                $highs[$i] - $lows[$i],
                abs($highs[$i] - $closes[$i - 1]),
                abs($lows[$i] - $closes[$i - 1])
            );
            $trArr[] = $tr;
        }

        $smoothedTR = array_sum(array_slice($trArr, 0, $period));
        $smoothedPlusDM = array_sum(array_slice($plusDM, 0, $period));
        $smoothedMinusDM = array_sum(array_slice($minusDM, 0, $period));

        $dxValues = [];

        for ($i = $period; $i < count($trArr); $i++) {
            $smoothedTR = $smoothedTR - ($smoothedTR / $period) + $trArr[$i];
            $smoothedPlusDM = $smoothedPlusDM - ($smoothedPlusDM / $period) + $plusDM[$i];
            $smoothedMinusDM = $smoothedMinusDM - ($smoothedMinusDM / $period) + $minusDM[$i];

            $plusDI = $smoothedTR > 0 ? ($smoothedPlusDM / $smoothedTR) * 100 : 0;
            $minusDI = $smoothedTR > 0 ? ($smoothedMinusDM / $smoothedTR) * 100 : 0;
            $diSum = $plusDI + $minusDI;
            $dx = $diSum > 0 ? abs($plusDI - $minusDI) / $diSum * 100 : 0;
            $dxValues[] = $dx;
        }

        if (count($dxValues) < $period) return null;

        $adx = array_sum(array_slice($dxValues, 0, $period)) / $period;
        for ($i = $period; $i < count($dxValues); $i++) {
            $adx = ($adx * ($period - 1) + $dxValues[$i]) / $period;
        }

        $lastPlusDI = $smoothedTR > 0 ? ($smoothedPlusDM / $smoothedTR) * 100 : 0;
        $lastMinusDI = $smoothedTR > 0 ? ($smoothedMinusDM / $smoothedTR) * 100 : 0;

        $prevADX = null;
        if (count($dxValues) > $period) {
            $prevADX = array_sum(array_slice($dxValues, 0, $period - 1)) / ($period - 1);
        }

        return [
            "adx" => round($adx, 2),
            "plus_di" => round($lastPlusDI, 2),
            "minus_di" => round($lastMinusDI, 2),
            "adx_subindo" => $prevADX !== null ? $adx > $prevADX : false,
        ];
    }

    private function macd(array $closes): ?array
    {
        if (count($closes) < 35) return null;

        $k12 = 2.0 / 13;
        $k26 = 2.0 / 27;
        $k9  = 2.0 / 10;

        $ema12 = array_sum(array_slice($closes, 0, 12)) / 12;
        $ema26 = array_sum(array_slice($closes, 0, 26)) / 26;

        // Inicializar EMA12 ate o candle 26
        for ($i = 12; $i < 26; $i++) {
            $ema12 = ($closes[$i] - $ema12) * $k12 + $ema12;
        }

        // Gerar serie MACD
        $series = [];
        for ($i = 26; $i < count($closes); $i++) {
            $ema12    = ($closes[$i] - $ema12) * $k12 + $ema12;
            $ema26    = ($closes[$i] - $ema26) * $k26 + $ema26;
            $series[] = $ema12 - $ema26;
        }

        if (count($series) < 9) return null;

        // EMA9 real da serie MACD = signal line
        $signal = array_sum(array_slice($series, 0, 9)) / 9;
        for ($i = 9; $i < count($series); $i++) {
            $signal = ($series[$i] - $signal) * $k9 + $signal;
        }

        $current = end($series);
        return [
            'macd'      => round($current, 8),
            'signal'    => round($signal,  8),
            'histogram' => round($current - $signal, 8),
        ];
    }

    /**
     * Detecta cruzamento do MACD pela linha zero.
     * BULLISH: MACD anterior negativo → atual positivo
     * BEARISH: MACD anterior positivo → atual negativo
     */
    private function detectarMacdZeroCross(?array $macdAtual, ?array $prevMacd): ?string
    {
        if ($macdAtual === null || $prevMacd === null) {
            return null;
        }

        $currentMacd = $macdAtual['macd'] ?? null;
        $previousMacd = $prevMacd['macd'] ?? null;

        if ($currentMacd === null || $previousMacd === null) {
            return null;
        }

        if ($previousMacd < 0 && $currentMacd >= 0) {
            return 'BULLISH';
        }

        if ($previousMacd > 0 && $currentMacd <= 0) {
            return 'BEARISH';
        }

        return null;
    }

    private function atr(array $highs, array $lows, array $closes, int $period = 14): ?float
    {
        $count = count($closes);
        if ($count < $period + 1) return null;
        $trValues = [];
        for ($i = 1; $i < $count; $i++) {
            $trValues[] = max(
                $highs[$i] - $lows[$i],
                abs($highs[$i] - $closes[$i - 1]),
                abs($lows[$i] - $closes[$i - 1])
            );
        }
        if (count($trValues) < $period) return null;
        $atr = array_sum(array_slice($trValues, 0, $period)) / $period;
        for ($i = $period; $i < count($trValues); $i++) {
            $atr = ($atr * ($period - 1) + $trValues[$i]) / $period;
        }
        return is_finite($atr) && $atr > 0 ? round($atr, 8) : null;
    }

    private function bollinger(array $closes, int $period = 20, float $stdDev = 2.0): ?array
    {
        if (count($closes) < $period) return null;
        $slice = array_slice($closes, -$period);
        $sma = array_sum($slice) / $period;
        $sqSum = 0;
        foreach ($slice as $p) $sqSum += pow($p - $sma, 2);
        $stdev = sqrt($sqSum / $period);
        if (!is_finite($sma) || !is_finite($stdev)) return null;
        return [
            "banda_media" => round($sma, 8),
            "banda_superior" => round($sma + ($stdev * $stdDev), 8),
            "banda_inferior" => round($sma - ($stdev * $stdDev), 8),
        ];
    }

    private function detectarCompressao(array $closes, array $volumes): array
    {
        $count = count($closes);
        if ($count < 20) return [
            "detectada" => false,
            "nivel" => "NENHUMA",
            "volume_decrescente" => false,
            "probabilidade" => 0,
        ];

        $recentCloses = array_slice($closes, -20);
        $recentVolumes = array_slice($volumes, -20);

        $maxPrice = max($recentCloses);
        $minPrice = min($recentCloses);
        $rangePercent = $minPrice > 0 ? (($maxPrice - $minPrice) / $minPrice) * 100 : 999;

        $firstHalfVol = array_sum(array_slice($recentVolumes, 0, 10));
        $secondHalfVol = array_sum(array_slice($recentVolumes, 10));
        $volumeDecrescente = $secondHalfVol < $firstHalfVol;

        $detectada = $rangePercent < 3.0 && $volumeDecrescente;
        $nivel = "NENHUMA";
        $probabilidade = 0;

        if ($detectada) {
            if ($rangePercent < 1.0) { $nivel = "SEVERA"; $probabilidade = 85; }
            elseif ($rangePercent < 2.0) { $nivel = "MODERADA"; $probabilidade = 65; }
            else { $nivel = "LEVE"; $probabilidade = 45; }
        }

        return [
            "detectada" => $detectada,
            "nivel" => $nivel,
            "volume_decrescente" => $volumeDecrescente,
            "probabilidade" => $probabilidade,
        ];
    }

    private function detectarDivergenciaRSI(array $closes, ?float $rsiAtual): string
    {
        if ($rsiAtual === null || count($closes) < 30) return 'NENHUMA';

        $recent = array_slice($closes, -14);
        $prev   = array_slice($closes, -28, 14);
        if (count($prev) < 14) return 'NENHUMA';

        // BEARISH: preco faz nova maxima mas RSI nao confirma (RSI < 70 = nao sobrecomprado)
        if (max($recent) > max($prev) && $rsiAtual < 70) return 'BEARISH';

        // BULLISH: preco faz nova minima mas RSI nao confirma (RSI > 30 = nao sobrevendido)
        if (min($recent) < min($prev) && $rsiAtual > 30) return 'BULLISH';

        return 'NENHUMA';
    }

    /**
     * Analisa volume como indicador independente.
     * Calcula tendencia, divergencia preco/volume, e ratio atual.
     *
     * @param array $candles Array de candles [timestamp, open, high, low, close, volume]
     * @return array ['tendencia', 'divergencia', 'ratio_atual', 'vol5', 'vol20']
     */
    public function analisarVolume(array $candles): array
    {
        if (count($candles) < 20) {
            return ['tendencia' => 'INDISPONIVEL', 'divergencia' => 'NENHUMA', 'ratio_atual' => 0, 'vol5' => 0, 'vol20' => 0];
        }

        $vols   = array_map(fn($c) => (float) $c[5], $candles);
        $closes = array_map(fn($c) => (float) $c[4], $candles);

        $vol5     = array_sum(array_slice($vols, -5))  / 5;
        $vol10    = array_sum(array_slice($vols, -10)) / 10;
        $vol20    = array_sum(array_slice($vols, -20)) / 20;
        $volAtual = end($vols);

        $tendencia = $vol5 > $vol10 ? 'CRESCENTE' : ($vol5 < $vol10 * 0.8 ? 'DECRESCENTE' : 'ESTAVEL');
        $ratio     = $vol20 > 0 ? round($volAtual / $vol20, 2) : 0;

        $preco5ini  = $closes[count($closes) - 5];
        $precoAtual = end($closes);
        $precoSubiu = $precoAtual > $preco5ini;

        $divergencia = 'NENHUMA';
        if ($precoSubiu && $tendencia === 'DECRESCENTE')  $divergencia = 'PRECO_SOBE_VOLUME_CAI';
        if (!$precoSubiu && $tendencia === 'DECRESCENTE') $divergencia = 'PRECO_CAI_VOLUME_CAI';
        if ($precoSubiu && $tendencia === 'CRESCENTE')    $divergencia = 'CONFIRMACAO_ALTA';
        if (!$precoSubiu && $tendencia === 'CRESCENTE')   $divergencia = 'CONFIRMACAO_BAIXA';

        return [
            'tendencia'   => $tendencia,
            'divergencia' => $divergencia,
            'ratio_atual' => $ratio,
            'vol5'        => round($vol5,  2),
            'vol20'       => round($vol20, 2),
        ];
    }

    /**
     * Detecta fase e eventos Wyckoff completos a partir de candles OHLCV.
     * Orquestra: identificarRange → detectarEventos → classificarFase → gerarNarrativa
     *
     * @param array $candles Array de candles [timestamp, open, high, low, close, volume]
     * @return array ['fase', 'evento', 'narrativa', 'gatilho', 'range']
     */
    public function detectarWyckoff(array $candles): array
    {
        if (count($candles) < 20) {
            return [
                'fase' => 'INDETERMINADO',
                'evento' => null,
                'narrativa' => 'Dados insuficientes para analise Wyckoff.',
                'gatilho' => 'N/A',
                'range' => ['teto' => 0, 'suporte' => 0]
            ];
        }

        $range = $this->identificarRange($candles);
        $eventos = $this->detectarEventos($candles, $range);

        $closes = array_map(fn($c) => (float)$c[4], $candles);
        $precoAtual = end($closes);

        $fase = $this->classificarFase($eventos, $range, $precoAtual);
        $evento = $this->ultimoEvento($eventos);
        $narrativa = $this->gerarNarrativaWyckoff($fase, $evento, $range);

        $gatilhos = [
            'ACUMULACAO_SPRING' => 'Compra no reteste do suporte do range',
            'DISTRIBUICAO_UAT' => 'Venda no reteste do teto do range',
            'MARKUP' => 'Compra em pullback ao teto do range anterior',
            'MARKDOWN' => 'Venda em repique ao suporte do range anterior',
            'ACUMULACAO_SC' => 'Aguardar AR e ST antes de posicionar',
            'ACUMULACAO_AR' => 'Aguardar ST para confirmar',
            'ACUMULACAO_ST' => 'Aguardar Spring para gatilho de compra',
            'ACUMULACAO_RANGE' => 'Aguardar evento direcional (Spring/SOS)',
            'DISTRIBUICAO_RANGE' => 'Aguardar evento direcional (UAT/SOB)',
        ];

        return [
            'fase' => $fase,
            'evento' => $evento,
            'narrativa' => $narrativa,
            'gatilho' => $gatilhos[$fase] ?? 'Monitorar',
            'range' => ['teto' => $range['teto'], 'suporte' => $range['suporte']]
        ];
    }

    /**
     * Identifica range lateral usando sliding window de 60, 40, 20 candles.
     * Range válido: amplitude < 8%.
     */
    private function identificarRange(array $candles): array
    {
        $count = count($candles);
        if ($count < 20) {
            return ['teto' => 0, 'suporte' => 0, 'inicio' => 0, 'valido' => false];
        }

        foreach ([60, 40, 20] as $window) {
            if ($count < $window) continue;
            $slice = array_slice($candles, -$window);
            $highs = array_map(fn($c) => (float)$c[2], $slice);
            $lows = array_map(fn($c) => (float)$c[3], $slice);
            $teto = max($highs);
            $suporte = min($lows);
            if ($suporte <= 0) continue;
            $amplitude = ($teto - $suporte) / $suporte;
            if ($amplitude < 0.08) {
                return [
                    'teto' => $teto,
                    'suporte' => $suporte,
                    'inicio' => $count - $window,
                    'valido' => true
                ];
            }
        }

        // Fallback: últimos 20 candles mesmo se >8%
        $slice = array_slice($candles, -20);
        $highs = array_map(fn($c) => (float)$c[2], $slice);
        $lows = array_map(fn($c) => (float)$c[3], $slice);
        return [
            'teto' => max($highs),
            'suporte' => min($lows),
            'inicio' => $count - 20,
            'valido' => false
        ];
    }

    /**
     * Busca o último evento de um tipo específico no array de eventos.
     */
    private function buscarUltimoEvento(array $eventos, string $tipo): ?array
    {
        $filtrados = array_filter($eventos, fn($e) => $e['tipo'] === $tipo);
        return !empty($filtrados) ? end($filtrados) : null;
    }

    /**
     * Detecta 7 eventos Wyckoff: SC, AR, ST, SPRING, UAT, SOS, SOB.
     */
    private function detectarEventos(array $candles, array $range): array
    {
        $eventos = [];
        $count = count($candles);
        if ($count < 20 || !$range['valido']) return $eventos;

        $teto = $range['teto'];
        $suporte = $range['suporte'];
        $inicio = $range['inicio'];

        // Volume médio dos últimos 20
        $volumes = array_map(fn($c) => (float)$c[5], array_slice($candles, -20));
        $volMedio = array_sum($volumes) / count($volumes);

        for ($i = max($inicio, 1); $i < $count; $i++) {
            $c = $candles[$i];
            $close = (float)$c[4];
            $low = (float)$c[3];
            $high = (float)$c[2];
            $vol = (float)$c[5];
            $prevClose = (float)$candles[$i - 1][4];

            // SC: Volume > 2x média + queda brusca (close < suporte * 1.01)
            if ($vol > $volMedio * 2 && $close < $suporte * 1.01 && $close < $prevClose) {
                $eventos[] = ['tipo' => 'SC', 'indice' => $i, 'preco' => $close, 'volume' => $vol];
            }

            // AR: Após SC, subida rápida com volume decrescente
            $lastSC = $this->buscarUltimoEvento($eventos, 'SC');
            if ($lastSC && $i > $lastSC['indice'] && $i <= $lastSC['indice'] + 5) {
                if ($close > $prevClose && $vol < $volMedio) {
                    $eventos[] = ['tipo' => 'AR', 'indice' => $i, 'preco' => $close, 'volume' => $vol];
                }
            }

            // ST: Retorno ao nível do SC com volume menor
            if ($lastSC && $i > $lastSC['indice'] + 5) {
                $scPreco = $lastSC['preco'];
                if (abs($close - $scPreco) / max($scPreco, 1) < 0.02 && $vol < $lastSC['volume']) {
                    $eventos[] = ['tipo' => 'ST', 'indice' => $i, 'preco' => $close, 'volume' => $vol];
                }
            }

            // Spring: Rompe suporte brevemente com volume baixo e retorna
            if ($low < $suporte && $close > $suporte && $vol < $volMedio) {
                $eventos[] = ['tipo' => 'SPRING', 'indice' => $i, 'preco' => $close, 'volume' => $vol];
            }

            // UAT: Rompe teto brevemente com volume baixo e retorna
            if ($high > $teto && $close < $teto && $vol < $volMedio) {
                $eventos[] = ['tipo' => 'UAT', 'indice' => $i, 'preco' => $close, 'volume' => $vol];
            }

            // SOS: Rompe teto com volume alto (sinal de força)
            if ($close > $teto && $vol > $volMedio * 1.5) {
                $eventos[] = ['tipo' => 'SOS', 'indice' => $i, 'preco' => $close, 'volume' => $vol];
            }

            // SOB: Rompe suporte com volume alto (sinal de fraqueza)
            if ($close < $suporte && $vol > $volMedio * 1.5) {
                $eventos[] = ['tipo' => 'SOB', 'indice' => $i, 'preco' => $close, 'volume' => $vol];
            }
        }

        return $eventos;
    }

    /**
     * Classifica a fase Wyckoff atual baseado nos eventos detectados e posição do preço.
     * 9 fases: MARKUP, MARKDOWN, ACUMULACAO_SPRING, DISTRIBUICAO_UAT, ACUMULACAO_ST,
     * ACUMULACAO_AR, ACUMULACAO_SC, DISTRIBUICAO_RANGE, ACUMULACAO_RANGE
     */
    private function classificarFase(array $eventos, array $range, float $precoAtual): string
    {
        if (empty($eventos)) {
            if ($precoAtual > $range['teto']) return 'MARKUP';
            if ($precoAtual < $range['suporte']) return 'MARKDOWN';
            return 'ACUMULACAO_RANGE';
        }

        $ultimo = end($eventos);
        $tiposPresentes = array_unique(array_column($eventos, 'tipo'));

        // Se último evento é SOS e preço acima do teto → MARKUP
        if ($ultimo['tipo'] === 'SOS' && $precoAtual > $range['teto']) return 'MARKUP';

        // Se último evento é SOB e preço abaixo do suporte → MARKDOWN
        if ($ultimo['tipo'] === 'SOB' && $precoAtual < $range['suporte']) return 'MARKDOWN';

        // Spring detectado
        if (in_array('SPRING', $tiposPresentes)) return 'ACUMULACAO_SPRING';

        // UAT detectado
        if (in_array('UAT', $tiposPresentes)) return 'DISTRIBUICAO_UAT';

        // ST detectado
        if (in_array('ST', $tiposPresentes)) return 'ACUMULACAO_ST';

        // AR detectado
        if (in_array('AR', $tiposPresentes)) return 'ACUMULACAO_AR';

        // SC detectado
        if (in_array('SC', $tiposPresentes)) return 'ACUMULACAO_SC';

        // Se preço está acima do teto sem eventos claros → distribuição range
        if ($precoAtual > ($range['teto'] + $range['suporte']) / 2) return 'DISTRIBUICAO_RANGE';

        // C-06: Preço significativamente abaixo do suporte = MARKDOWN real, não acumulação
        if ($precoAtual < $range['suporte'] * 0.96) {
            return 'MARKDOWN';
        }

        return 'ACUMULACAO_RANGE';
    }

    /**
     * Gera narrativa em português para a fase Wyckoff atual.
     * Inclui informação de range (teto/suporte) quando disponível.
     */
    private function gerarNarrativaWyckoff(string $fase, ?string $evento, array $range): string
    {
        $narrativas = [
            'ACUMULACAO_SC' => 'Selling Climax identificado. Volume extremo com queda abrupta sugere capitulacao vendedora. Possivel inicio de acumulacao institucional.',
            'ACUMULACAO_AR' => 'Automatic Rally apos climax. Recuperacao natural com volume decrescente. Aguardar Secondary Test para confirmar fundo.',
            'ACUMULACAO_ST' => 'Secondary Test confirmado. Preco retornou ao nivel do climax com volume reduzido. Suporte validado.',
            'ACUMULACAO_RANGE' => 'Ativo em range de acumulacao. Institucionais possivelmente absorvendo oferta. Aguardar Spring ou SOS.',
            'ACUMULACAO_SPRING' => 'Spring detectado. Falso rompimento do suporte com volume baixo. Sinal classico de absorcao institucional. Gatilho de compra proximo.',
            'DISTRIBUICAO_RANGE' => 'Ativo em range de distribuicao. Institucionais possivelmente distribuindo posicoes. Aguardar UAT ou SOB.',
            'DISTRIBUICAO_UAT' => 'Upthrust After Distribution detectado. Falso rompimento do teto com volume baixo. Sinal de distribuicao institucional. Gatilho de venda proximo.',
            'MARKUP' => 'Fase de markup ativa. Preco rompeu range de acumulacao com forca. Tendencia de alta em desenvolvimento.',
            'MARKDOWN' => 'Fase de markdown ativa. Preco rompeu range de distribuicao. Tendencia de baixa em desenvolvimento.',
        ];

        $narrativa = $narrativas[$fase] ?? 'Fase Wyckoff indeterminada.';

        if ($range['teto'] > 0 && $range['suporte'] > 0) {
            $narrativa .= sprintf(' Range: %.4f (suporte) a %.4f (teto).', $range['suporte'], $range['teto']);
        }

        return $narrativa;
    }

    /**
     * Retorna o tipo do último evento detectado, ou null para array vazio.
     */
    public function ultimoEvento(array $eventos): ?string
    {
        if (empty($eventos)) return null;
        return end($eventos)['tipo'];
    }

    /**
     * Calcula Volume Profile distribuindo volume em bins de preço.
     * Identifica POC (Point of Control), HVN (High Volume Nodes) e LVN (Low Volume Nodes).
     *
     * @param array $candles Array de candles [timestamp, open, high, low, close, volume]
     * @param int $bins Número de faixas de preço para distribuição
     * @return array ['poc' => float, 'hvn' => float[], 'lvn' => float[]]
     */
    public function calcularVolumeProfile(array $candles, int $bins = 50): array
    {
        if (count($candles) < 10) {
            return ['poc' => 0, 'hvn' => [], 'lvn' => []];
        }

        $highs = array_map(fn($c) => (float)$c[2], $candles);
        $lows = array_map(fn($c) => (float)$c[3], $candles);

        $priceMax = max($highs);
        $priceMin = min($lows);
        $range = $priceMax - $priceMin;

        if ($range <= 0) {
            return ['poc' => 0, 'hvn' => [], 'lvn' => []];
        }

        $binSize = $range / $bins;
        $volumeByBin = array_fill(0, $bins, 0.0);

        // Distribui volume de cada candle proporcionalmente nos bins que ele cobre
        foreach ($candles as $c) {
            $low = (float)$c[3];
            $high = (float)$c[2];
            $vol = (float)$c[5];
            $startBin = (int)floor(($low - $priceMin) / $binSize);
            $endBin = (int)floor(($high - $priceMin) / $binSize);
            $startBin = max(0, min($startBin, $bins - 1));
            $endBin = max(0, min($endBin, $bins - 1));
            $numBins = $endBin - $startBin + 1;
            $volPerBin = $vol / max($numBins, 1);
            for ($i = $startBin; $i <= $endBin; $i++) {
                $volumeByBin[$i] += $volPerBin;
            }
        }

        // POC = bin com maior volume
        $pocBin = array_keys($volumeByBin, max($volumeByBin))[0];
        $poc = $priceMin + ($pocBin + 0.5) * $binSize;

        // HVN e LVN baseados na média de volume por bin
        $avgVolume = array_sum($volumeByBin) / $bins;
        $hvn = [];
        $lvn = [];

        for ($i = 0; $i < $bins; $i++) {
            $binPrice = $priceMin + ($i + 0.5) * $binSize;
            if ($volumeByBin[$i] > $avgVolume * 1.5) {
                $hvn[] = round($binPrice, 8);
            }
            if ($volumeByBin[$i] < $avgVolume * 0.5) {
                $lvn[] = round($binPrice, 8);
            }
        }

        return [
            'poc' => round($poc, 8),
            'hvn' => $hvn,
            'lvn' => $lvn,
        ];
    }

    public function detectarPadraoCandle(array $candles): string
    {
        if (count($candles) < 2) return "NENHUM";

        $ultimo = end($candles);
        $penultimo = $candles[count($candles) - 2];

        $open = (float)$ultimo[1];
        $high = (float)$ultimo[2];
        $low = (float)$ultimo[3];
        $close = (float)$ultimo[4];

        $body = abs($close - $open);
        $range = $high - $low;
        $upperShadow = $high - max($open, $close);
        $lowerShadow = min($open, $close) - $low;

        if ($range <= 0) return "NENHUM";

        // DOJI: corpo < 10% do range
        if ($body < $range * 0.10) return "DOJI";

        // ENGOLFO ALTISTA: candle atual bullish engolfa o anterior bearish
        $prevOpen = (float)$penultimo[1];
        $prevClose = (float)$penultimo[4];
        $prevBody = abs($prevClose - $prevOpen);
        if ($close > $open && $prevClose < $prevOpen && $body > $prevBody
            && $close > $prevOpen && $open < $prevClose) {
            return "ENGOLFO_ALTISTA";
        }

        // ENGOLFO BAIXISTA: candle atual bearish engolfa o anterior bullish
        if ($close < $open && $prevClose > $prevOpen && $body > $prevBody
            && $open > $prevClose && $close < $prevOpen) {
            return "ENGOLFO_BAIXISTA";
        }

        // MARTELO: sombra inferior > 2x corpo, sombra superior pequena
        if ($lowerShadow > $body * 2 && $upperShadow < $body * 0.5) {
            return "MARTELO";
        }

        // ESTRELA CADENTE: sombra superior > 2x corpo, sombra inferior pequena
        if ($upperShadow > $body * 2 && $lowerShadow < $body * 0.5) {
            return "ESTRELA_CADENTE";
        }

        // PIN BAR: sombra longa (qualquer direção) > 2.5x corpo
        if ($lowerShadow > $body * 2.5 || $upperShadow > $body * 2.5) {
            return "PIN_BAR";
        }

        return "NENHUM";
    }

    public function calcularDivergenciaCVD(array $candles, array $cvdData): string
    {
        if (count($candles) < 14 || count($cvdData) < 14) return "NENHUMA";

        $recentCandles = array_slice($candles, -14);
        $recentCVD = array_slice($cvdData, -14);

        $closes = array_map(fn($c) => (float)$c[4], $recentCandles);
        $cvdDeltas = array_map(fn($d) => (float)($d['delta'] ?? $d), $recentCVD);

        // Verifica se closes fazem nova mínima vs período anterior
        $prevCandles = array_slice($candles, -28, 14);
        if (count($prevCandles) < 14) return "NENHUMA";
        $prevCloses = array_map(fn($c) => (float)$c[4], $prevCandles);

        $prevCVD = array_slice($cvdData, -28, 14);
        if (count($prevCVD) < 14) return "NENHUMA";
        $prevCvdDeltas = array_map(fn($d) => (float)($d['delta'] ?? $d), $prevCVD);

        $recentLow = min($closes);
        $prevLow = min($prevCloses);
        $recentHigh = max($closes);
        $prevHigh = max($prevCloses);

        $recentCVDLow = min($cvdDeltas);
        $prevCVDLow = min($prevCvdDeltas);
        $recentCVDHigh = max($cvdDeltas);
        $prevCVDHigh = max($prevCvdDeltas);

        // BULLISH: preço faz nova mínima, CVD faz mínima mais alta
        if ($recentLow < $prevLow && $recentCVDLow > $prevCVDLow) {
            return "BULLISH";
        }

        // BEARISH: preço faz nova máxima, CVD faz máxima mais baixa
        if ($recentHigh > $prevHigh && $recentCVDHigh < $prevCVDHigh) {
            return "BEARISH";
        }

        return "NENHUMA";
    }
}
