<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class YahooFinanceService
{
    private string $proxyUrl;
    private string $proxyFallbackUrl;
    private int $timeout;
    private int $cacheTtl;

    private const YAHOO_BASE = 'https://query1.finance.yahoo.com/v8/finance/chart/';

    public function __construct()
    {
        $this->proxyUrl = config('yahoo.proxy_url', 'https://api.allorigins.win/raw?url=');
        $this->proxyFallbackUrl = config('yahoo.proxy_fallback_url', 'https://corsproxy.io/?');
        $this->timeout = config('yahoo.timeout', 15);
        $this->cacheTtl = config('yahoo.cache_ttl', 300);
    }

    /**
     * C-01: Chamada direta ao Yahoo Finance sem proxy CORS.
     * Proxies (allorigins.win, corsproxy.io) são para browser — não funcionam server-side.
     */
    private function fetchDirect(string $symbol): array
    {
        $url      = self::YAHOO_BASE . rawurlencode($symbol) . '?interval=1d&range=2d';
        $cacheKey = "yahoo:quote:{$symbol}";

        return CacheManager::remember($cacheKey, function () use ($url, $symbol) {
            $response = Http::timeout($this->timeout)
                ->withHeaders([
                    'User-Agent' => 'Mozilla/5.0 (compatible; GenesisLabs/2.0)',
                    'Accept'     => 'application/json',
                ])
                ->get($url);

            if (!$response->successful()) {
                Log::error("YahooFinanceService HTTP error", [
                    'symbol' => $symbol,
                    'status' => $response->status(),
                ]);
                throw new \RuntimeException("Yahoo Finance error {$symbol}: {$response->status()}");
            }

            return $response->json();
        }, $this->cacheTtl);
    }

    public function getQuote(string $symbol): array
    {
        $data = $this->fetchDirect($symbol);

        $result = $data['chart']['result'][0] ?? null;

        if (!$result) {
            throw new \RuntimeException("No data returned for symbol: {$symbol}");
        }

        $meta = $result['meta'] ?? [];

        return [
            'symbol' => $meta['symbol'] ?? $symbol,
            'price' => $meta['regularMarketPrice'] ?? null,
            'previous_close' => $meta['chartPreviousClose'] ?? null,
            'currency' => $meta['currency'] ?? 'USD',
            'exchange' => $meta['exchangeName'] ?? null,
            'market_state' => $meta['marketState'] ?? null,
        ];
    }

    public function getVIX(): array
    {
        return $this->getQuote('^VIX');
    }

    public function getDXY(): array
    {
        return $this->getQuote('DX-Y.NYB');
    }

    public function getSP500(): array
    {
        return $this->getQuote('^GSPC');
    }

    public function getYield10Y(): array
    {
        return $this->getQuote('^TNX');
    }
}
