<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;

class MotorExecucaoService
{
    const RISCO_MAX_CONTA = 0.02;
    const ALAV_MAX = 10.0;
    const MARGEM_SEG_LIQ = 0.05;
    const RR_MINIMO = 1.5;
    const MARGEM_WICK = 0.003;

    public static function calcularLiquidacao(float $entrada, string $direcao, float $alavancagem, float $mm = 0.005): float
    {
        if ($alavancagem <= 1) {
            return $direcao === 'LONG' ? 0 : INF;
        }
        if ($direcao === 'LONG') {
            return $entrada * (1 - 1 / $alavancagem + $mm);
        }
        return $entrada * (1 + 1 / $alavancagem - $mm);
    }

    public static function gerarSetup(
        float $preco,
        string $direcao,
        int $score,
        int $confianca,
        float $atr,
        string $regime,
        array $hvn,
        array $lvn,
        array $liqClusters,
        float $poc,
        array $elementosVisuais = [],
        string $scoreVies = 'NEUTRO'
    ): array {
        if ($preco <= 0) {
            return [
                'acao' => $direcao,
                'motivo' => 'Preço inválido (0) — não foi possível calcular setup',
                'setup' => [
                    'entrada' => 0,
                    'stop' => 0,
                    'tp1' => 0,
                    'tp2' => 0,
                    'tp3' => 0,
                    'alavancagem' => 1,
                    'liquidacao' => 'N/A',
                    'riscoPct' => 0,
                    'rr1' => 0,
                    'verificacao' => '✗ INVÁLIDO',
                    'hierarquiaStop' => 'N/A',
                    'tamanhoSugerido' => '',
                ],
                'planoB' => null,
                'zonaInteresse' => ['tipo' => 'N/A', 'zona' => 'N/A', 'invalidacao' => null],
                'validacaoDirecao' => ['consistente' => false, 'motivo' => 'Preço inválido', 'alertaContradicao' => null],
            ];
        }

        // Alavancagem máxima por score
        $alavMax = self::limitarAlavancagemPorScore($score);

        // LOG DEBUG: Entrada do Motor com parâmetros decisivos
        Log::info("DEBUG_MOTOR_SETUP: Inicio gerarSetup", [
            "preco" => $preco,
            "direcao" => $direcao,
            "score" => $score,
            "confianca" => $confianca,
            "atr" => $atr,
            "regime" => $regime,
            "alavMax" => $alavMax,
            "poc" => $poc,
            "hvn_count" => count($hvn),
            "lvn_count" => count($lvn),
            "liqClusters_above" => count($liqClusters['above'] ?? []),
            "liqClusters_below" => count($liqClusters['below'] ?? []),
            "elementosVisuais_keys" => array_keys($elementosVisuais),
            "scoreVies" => $scoreVies,
        ]);

        // ATR multiplier baseado em score
        $atrMult = 2.5;
        if ($score < 50) {
            $atrMult = 3.5;
        } elseif ($score < 65) {
            $atrMult = 3.0;
        } elseif ($score < 75) {
            $atrMult = 2.5;
        }

        if ($confianca < 50) {
            $alavMax = min($alavMax, 2.0);
        }

        // Plano A: entrada no preço atual
        $planoA = $direcao === 'LONG'
            ? self::setupLong($preco, $atr, $hvn, $lvn, $liqClusters, $poc, $elementosVisuais, $atrMult, $alavMax)
            : self::setupShort($preco, $atr, $hvn, $lvn, $liqClusters, $poc, $elementosVisuais, $atrMult, $alavMax);

        // Validação geométrica do Plano A
        $geometria = self::validarGeometria($planoA['entrada'], $planoA['stop'], $direcao);
        if (!$geometria['valido']) {
            return [
                'acao' => $direcao,
                'motivo' => $geometria['motivo'],
                'setup' => array_merge($planoA, [
                    'verificacao' => '✗ INVÁLIDO',
                    'tamanhoSugerido' => '',
                ]),
                'planoB' => null,
                'zonaInteresse' => self::zonaInteresse($regime, $preco, $atr, $poc, $hvn),
                'validacaoDirecao' => self::validarDirecao($direcao, $score, $scoreVies),
            ];
        }

        // Recalcular por alavancagem (inclui loop de segurança e tamanhoSugerido)
        $planoA = self::recalcularPorAlavancagem($planoA, $alavMax, $direcao);

        // Verificar RR mínimo e tentar recalcular TPs se < 1.5
        $rr = self::calcularRR($planoA['entrada'], $planoA['stop'], $planoA['tp1']);
        if ($rr < self::RR_MINIMO) {
            // Buscar próximo HVN na direção do trade como novo TP1
            $pdl = (float) ($elementosVisuais['pdl'] ?? 0);
            $pdh = (float) ($elementosVisuais['pdh'] ?? 0);

            if ($direcao === 'LONG') {
                $hvnAcima = array_filter($hvn, fn($h) => $h > $planoA['tp1']);
                if (!empty($hvnAcima)) {
                    $novoTp1 = min($hvnAcima);
                    $planoA['tp1'] = round($novoTp1, 4);
                    $rr = self::calcularRR($planoA['entrada'], $planoA['stop'], $planoA['tp1']);
                    $planoA['rr1'] = round($rr, 2);
                }
            } else {
                $hvnAbaixo = array_filter($hvn, fn($h) => $h < $planoA['tp1'] && $h > 0);
                if (!empty($hvnAbaixo)) {
                    $novoTp1 = max($hvnAbaixo);
                    $planoA['tp1'] = round($novoTp1, 4);
                    $rr = self::calcularRR($planoA['entrada'], $planoA['stop'], $planoA['tp1']);
                    $planoA['rr1'] = round($rr, 2);
                }
            }

            // Se ainda < 1.5, informar risco sem bloquear
            if ($rr < self::RR_MINIMO) {
                $planoA['avisoRR'] = "RR {$planoA['rr1']} abaixo do mínimo recomendado (1.5). Operar com cautela.";
            }
        }

        // Plano B: entrada em HVN (pullback técnico)
        $planoB = self::gerarPlanoB($preco, $direcao, $atr, $hvn, $lvn, $liqClusters, $poc, $elementosVisuais, $atrMult, $alavMax);

        // Validação de direção vs score viés
        $validacaoDirecao = self::validarDirecao($direcao, $score, $scoreVies);

        return [
            'acao' => $direcao,
            'motivo' => $score < 65
                ? "Score {$score}/100 — Operar com cautela. Alavancagem reduzida."
                : "Setup confirmado. Score {$score}/100.",
            'setup' => $planoA,
            'planoB' => $planoB,
            'zonaInteresse' => self::zonaInteresse($regime, $preco, $atr, $poc, $hvn),
            'validacaoDirecao' => $validacaoDirecao,
        ];
    }

    /**
     * Calcula o stop para posição LONG usando hierarquia estrutural.
     * Hierarquia: LVN LuxAlgo > Suporte Visual > PDL > POC > ATR fallback
     * Inclui validação geométrica final: se stop >= entrada, força ATR como fallback seguro.
     *
     * @return array ['stop' => float, 'hierarquia' => string]
     */
    private static function calcularStopLong(
        float $preco,
        array $lvn,
        array $elementosVisuais,
        float $pdl,
        float $poc,
        float $atr,
        float $atrMult
    ): array {
        $stop = null;
        $hierarquia = null;

        // 1. LVN do LuxAlgo abaixo do preço
        $lvnLuxalgo = $elementosVisuais['lvn_luxalgo'] ?? [];
        $lvnAbaixo = array_filter($lvnLuxalgo, fn($v) => $v < $preco);
        if (!empty($lvnAbaixo)) {
            $nivelMaisProximo = max($lvnAbaixo);
            $stop = $nivelMaisProximo * (1 - self::MARGEM_WICK);
            $hierarquia = 'LVN_LUXALGO';
        }

        // 2. Suportes visuais abaixo do preço
        if ($stop === null) {
            $suportes = $elementosVisuais['suportes'] ?? [];
            $suportesAbaixo = array_filter($suportes, fn($s) => $s < $preco);
            if (!empty($suportesAbaixo)) {
                $nivelMaisProximo = max($suportesAbaixo);
                $stop = $nivelMaisProximo * (1 - self::MARGEM_WICK);
                $hierarquia = 'SUPORTE_VISUAL';
            }
        }

        // 3. PDL (Previous Day Low)
        if ($stop === null && $pdl > 0 && $pdl < $preco) {
            $stop = $pdl * (1 - self::MARGEM_WICK);
            $hierarquia = 'PDL';
        }

        // 4. POC
        if ($stop === null && $poc > 0 && $poc < $preco) {
            $stop = $poc * (1 - self::MARGEM_WICK);
            $hierarquia = 'POC';
        }

        // 5. Fallback ATR
        if ($stop === null) {
            $stop = $preco - ($atr * $atrMult);
            $hierarquia = 'ATR_FALLBACK';
        }

        // Validação geométrica: stop deve estar abaixo da entrada para LONG
        if ($stop >= $preco) {
            // Stop geometricamente invalido — forcando ATR como fallback seguro
            $stop = $preco - ($atr * $atrMult);
            $hierarquia = 'ATR_FORCADO';
        }

        return [
            'stop' => $stop,
            'hierarquia' => $hierarquia,
        ];
    }

    /**
     * Calcula o stop para posição SHORT usando hierarquia estrutural.
     * Hierarquia: HVN LuxAlgo > Resistência Visual > PDH > Fibonacci 0.618 > ATR fallback
     *
     * @return array ['stop' => float, 'hierarquia' => string]
     */
    private static function calcularStopShort(
        float $preco,
        array $hvn,
        array $elementosVisuais,
        float $pdh,
        float $poc,
        float $atr,
        float $atrMult
    ): array {
        $stop = null;
        $hierarquia = null;

        // 1. HVN do LuxAlgo acima do preço
        $hvnLuxalgo = $elementosVisuais['hvn_luxalgo'] ?? [];
        $hvnAcima = array_filter($hvnLuxalgo, fn($v) => $v > $preco);
        if (!empty($hvnAcima)) {
            $nivelMaisProximo = min($hvnAcima);
            $stop = $nivelMaisProximo * (1 + self::MARGEM_WICK);
            $hierarquia = 'HVN_LUXALGO';
        }

        // 2. Resistências visuais acima do preço
        if ($stop === null) {
            $resistencias = $elementosVisuais['resistencias'] ?? [];
            $resistenciasAcima = array_filter($resistencias, fn($r) => $r > $preco);
            if (!empty($resistenciasAcima)) {
                $nivelMaisProximo = min($resistenciasAcima);
                $stop = $nivelMaisProximo * (1 + self::MARGEM_WICK);
                $hierarquia = 'RESISTENCIA_VISUAL';
            }
        }

        // 3. PDH (Previous Day High)
        if ($stop === null && $pdh > 0 && $pdh > $preco) {
            $stop = $pdh * (1 + self::MARGEM_WICK);
            $hierarquia = 'PDH';
        }

        // 4. Fibonacci 0.618
        if ($stop === null && $atr > 0) {
            $stop = ($preco + ($atr * 1.618)) * (1 + self::MARGEM_WICK);
            $hierarquia = 'FIBONACCI_0618';
        }

        // 5. Fallback ATR
        if ($stop === null) {
            $stop = $preco + ($atr * $atrMult);
            $hierarquia = 'ATR_FALLBACK';
        }

        // Validação geométrica: stop deve estar acima da entrada para SHORT
        if ($stop <= $preco) {
            // Stop geometricamente invalido — forcando ATR como fallback seguro
            $stop = $preco + ($atr * $atrMult);
            $hierarquia = 'ATR_FORCADO';
        }

        return [
            'stop' => $stop,
            'hierarquia' => $hierarquia,
        ];
    }

    /**
     * Calcula Take-Profits ancorados em estrutura.
     * LONG: TP1=primeiro HVN acima, TP2=primeiro cluster liq acima, TP3=TP2*1.08
     * SHORT: TP1=primeiro HVN abaixo, TP2=primeiro cluster liq abaixo, TP3=TP2*0.92
     *
     * @return array ['tp1' => float, 'tp2' => float, 'tp3' => float]
     */
    /**
     * C-04: Adicionado $stop como parâmetro para garantir RR mínimo de 1:1.5
     */
    private static function calcularTPs(
        float $entrada,
        string $direcao,
        array $hvn,
        array $liqClusters,
        float $poc,
        float $pdh,
        float $pdl,
        float $stop = 0
    ): array {
        if ($direcao === 'LONG') {
            // TP1: primeiro HVN acima da entrada (fallback: POC se POC > entrada)
            $hvnAcima = array_filter($hvn, fn($h) => $h > $entrada);
            $tp1 = !empty($hvnAcima) ? min($hvnAcima) : ($poc > $entrada ? $poc : $entrada * 1.06);

            // TP2: primeiro cluster de liquidação acima (fallback: PDH)
            $liqAcima = array_filter($liqClusters['above'] ?? [], fn($l) => $l > $entrada);
            $tp2 = !empty($liqAcima) ? min($liqAcima) : ($pdh > $entrada ? $pdh : $entrada * 1.10);

            // TP3: extensão de 8% além de TP2
            $tp3 = $tp2 * 1.08;

            // Validação geométrica: TPs devem estar acima da entrada para LONG
            if ($tp1 <= $entrada) $tp1 = $entrada * 1.06;
            if ($tp2 <= $tp1)     $tp2 = $tp1 * 1.04;
            if ($tp3 <= $tp2)     $tp3 = $tp2 * 1.08;

            return ['tp1' => $tp1, 'tp2' => $tp2, 'tp3' => $tp3];
        }

        // SHORT
        // TP1: primeiro HVN abaixo da entrada (fallback: POC se POC < entrada)
        $hvnAbaixo = array_filter($hvn, fn($h) => $h < $entrada);
        $tp1 = !empty($hvnAbaixo) ? max($hvnAbaixo) : ($poc < $entrada ? $poc : $entrada * 0.94);

        // TP2: primeiro cluster de liquidação abaixo (fallback: PDL)
        $liqAbaixo = array_filter($liqClusters['below'] ?? [], fn($l) => $l < $entrada);
        $tp2 = !empty($liqAbaixo) ? max($liqAbaixo) : ($pdl > 0 && $pdl < $entrada ? $pdl : $entrada * 0.90);

        // TP3: extensão de 8% além de TP2 (para SHORT, abaixo)
        $tp3 = $tp2 * 0.92;

        // Validação geométrica: TPs devem estar abaixo da entrada para SHORT
        if ($tp1 >= $entrada) $tp1 = $entrada * 0.94;
        if ($tp2 >= $tp1)     $tp2 = $tp1 * 0.96;
        if ($tp3 >= $tp2)     $tp3 = $tp2 * 0.92;

        // C-04: Garantir RR mínimo de 1:1.5 quando stop disponível
        if ($stop > 0) {
            $riscoAbs   = abs($stop - $entrada);
            $tp1MinRR15 = $entrada - ($riscoAbs * 1.5);
            $tp2MinRR25 = $entrada - ($riscoAbs * 2.5);
            if ($tp1 > $tp1MinRR15) $tp1 = round($tp1MinRR15, 4);
            if ($tp2 > $tp2MinRR25) $tp2 = round($tp2MinRR25, 4);
            if ($tp3 >= $tp2)       $tp3 = round($tp2 * 0.92, 4);
        }

        return ['tp1' => $tp1, 'tp2' => $tp2, 'tp3' => $tp3];
    }

    /**
     * Setup LONG usando hierarquia de stops e TPs estruturais.
     */
    private static function setupLong(
        float $preco,
        float $atr,
        array $hvn,
        array $lvn,
        array $liqClusters,
        float $poc,
        array $elementosVisuais,
        float $atrMult,
        float $alavMax
    ): array {
        // Extrair PDL e PDH de elementosVisuais
        $pdl = (float) ($elementosVisuais['pdl'] ?? 0);
        $pdh = (float) ($elementosVisuais['pdh'] ?? 0);

        // Calcular stop com hierarquia estrutural
        $stopResult = self::calcularStopLong($preco, $lvn, $elementosVisuais, $pdl, $poc, $atr, $atrMult);
        $stop = $stopResult['stop'];
        $hierarquia = $stopResult['hierarquia'];

        // Calcular TPs ancorados em estrutura
        $tps = self::calcularTPs($preco, 'LONG', $hvn, $liqClusters, $poc, $pdh, $pdl, $stop);

        // Calcular risco e alavancagem
        $risco = ($preco - $stop) / max($preco, 0.0001);
        $alav = max(min(self::RISCO_MAX_CONTA / max($risco, 0.001), $alavMax), 1.0);
        $liq = self::calcularLiquidacao($preco, 'LONG', $alav);

        // Loop de segurança: reduzir alavancagem se stop dentro da margem de liquidação
        $t = 0;
        while ($liq > 0 && $stop <= $liq * (1 + self::MARGEM_SEG_LIQ) && $alav > 1.0 && $t < 20) {
            $alav -= 0.5;
            $liq = self::calcularLiquidacao($preco, 'LONG', $alav);
            $t++;
        }
        $alav = max($alav, 1.0);
        $liq = self::calcularLiquidacao($preco, 'LONG', $alav);

        $rr1 = $preco !== $stop ? ($tps['tp1'] - $preco) / max($preco - $stop, 0.0001) : 0;

        // LOG DEBUG: Setup LONG calculado
        Log::info("DEBUG_SETUP_LONG: Niveis calculados", [
            "preco" => $preco,
            "stop" => round($stop, 4),
            "hierarquia" => $hierarquia,
            "tp1" => round($tps['tp1'], 4),
            "tp2" => round($tps['tp2'], 4),
            "tp3" => round($tps['tp3'], 4),
            "alavancagem" => round($alav, 1),
            "risco_pct" => round($risco * 100, 2),
            "rr1" => round($rr1, 2),
            "pdl" => $pdl,
            "pdh" => $pdh,
            "suportes_visuais" => $elementosVisuais['suportes'] ?? [],
            "lvn_luxalgo" => $elementosVisuais['lvn_luxalgo'] ?? [],
        ]);

        return [
            'entrada' => round($preco, 4),
            'stop' => round($stop, 4),
            'tp1' => round($tps['tp1'], 4),
            'tp2' => round($tps['tp2'], 4),
            'tp3' => round($tps['tp3'], 4),
            'alavancagem' => round($alav, 1),
            'liquidacao' => $liq > 0 ? round($liq, 4) : 'N/A (1x)',
            'riscoPct' => round($risco * 100, 2),
            'rr1' => round($rr1, 2),
            'verificacao' => $stop < ($liq > 0 ? $liq * (1 + self::MARGEM_SEG_LIQ) : INF) ? '✓ SEGURO' : '✗ INSEGURO',
            'hierarquiaStop' => $hierarquia,
        ];
    }

    /**
     * Setup SHORT usando hierarquia de stops e TPs estruturais.
     */
    private static function setupShort(
        float $preco,
        float $atr,
        array $hvn,
        array $lvn,
        array $liqClusters,
        float $poc,
        array $elementosVisuais,
        float $atrMult,
        float $alavMax
    ): array {
        // Extrair PDH e PDL de elementosVisuais
        $pdh = (float) ($elementosVisuais['pdh'] ?? 0);
        $pdl = (float) ($elementosVisuais['pdl'] ?? 0);

        // Calcular stop com hierarquia estrutural
        $stopResult = self::calcularStopShort($preco, $hvn, $elementosVisuais, $pdh, $poc, $atr, $atrMult);
        $stop = $stopResult['stop'];
        $hierarquia = $stopResult['hierarquia'];

        // Calcular TPs ancorados em estrutura
        $tps = self::calcularTPs($preco, 'SHORT', $hvn, $liqClusters, $poc, $pdh, $pdl, $stop);

        // Calcular risco e alavancagem
        $risco = ($stop - $preco) / max($preco, 0.0001);
        $alav = max(min(self::RISCO_MAX_CONTA / max($risco, 0.001), $alavMax), 1.0);
        $liq = self::calcularLiquidacao($preco, 'SHORT', $alav);

        // Loop de segurança: reduzir alavancagem se stop dentro da margem de liquidação
        $t = 0;
        while ($liq < INF && $stop >= $liq * (1 - self::MARGEM_SEG_LIQ) && $alav > 1.0 && $t < 20) {
            $alav -= 0.5;
            $liq = self::calcularLiquidacao($preco, 'SHORT', $alav);
            $t++;
        }
        $alav = max($alav, 1.0);
        $liq = self::calcularLiquidacao($preco, 'SHORT', $alav);

        $rr1 = $stop !== $preco ? ($preco - $tps['tp1']) / max($stop - $preco, 0.0001) : 0;

        // LOG DEBUG: Setup SHORT calculado
        Log::info("DEBUG_SETUP_SHORT: Niveis calculados", [
            "preco" => $preco,
            "stop" => round($stop, 4),
            "hierarquia" => $hierarquia,
            "tp1" => round($tps['tp1'], 4),
            "tp2" => round($tps['tp2'], 4),
            "tp3" => round($tps['tp3'], 4),
            "alavancagem" => round($alav, 1),
            "risco_pct" => round($risco * 100, 2),
            "rr1" => round($rr1, 2),
            "pdh" => $pdh,
            "pdl" => $pdl,
            "resistencias_visuais" => $elementosVisuais['resistencias'] ?? [],
            "hvn_luxalgo" => $elementosVisuais['hvn_luxalgo'] ?? [],
        ]);

        return [
            'entrada' => round($preco, 4),
            'stop' => round($stop, 4),
            'tp1' => round($tps['tp1'], 4),
            'tp2' => round($tps['tp2'], 4),
            'tp3' => round($tps['tp3'], 4),
            'alavancagem' => round($alav, 1),
            'liquidacao' => $liq < INF ? round($liq, 4) : 'N/A (1x)',
            'riscoPct' => round($risco * 100, 2),
            'rr1' => round($rr1, 2),
            'verificacao' => $stop > ($liq < INF ? $liq * (1 - self::MARGEM_SEG_LIQ) : 0) ? '✓ SEGURO' : '✗ INSEGURO',
            'hierarquiaStop' => $hierarquia,
        ];
    }

    /**
     * Gera Plano B com entrada técnica em HVN (fallback POC).
     * LONG: entrada no primeiro HVN abaixo do preço (fallback POC), stop ATR*0.8
     * SHORT: entrada no primeiro HVN acima do preço (fallback POC), stop ATR*0.8
     */
    private static function gerarPlanoB(
        float $preco,
        string $direcao,
        float $atr,
        array $hvn,
        array $lvn,
        array $liqClusters,
        float $poc,
        array $elementosVisuais,
        float $atrMult,
        float $alavMax
    ): array {
        $pdl = (float) ($elementosVisuais['pdl'] ?? 0);
        $pdh = (float) ($elementosVisuais['pdh'] ?? 0);
        $atrMultB = $atrMult * 0.8;

        if ($direcao === 'LONG') {
            // Entrada B: primeiro HVN abaixo do preço (fallback POC)
            $hvnAbaixo = array_filter($hvn, fn($h) => $h < $preco);
            $entradaB = !empty($hvnAbaixo) ? max($hvnAbaixo) : ($poc > 0 && $poc < $preco ? $poc : $preco - ($atr * 0.5));

            // Garantir que entrada B está abaixo do preço atual
            if ($entradaB >= $preco) {
                $entradaB = $preco - ($atr * 0.5);
            }

            // Stop com multiplicador ATR reduzido (0.8x)
            $stopResultB = self::calcularStopLong($entradaB, $lvn, $elementosVisuais, $pdl, $poc, $atr, $atrMultB);
            $stopB = $stopResultB['stop'];

            // TPs recalculados a partir da entrada B
            $tps = self::calcularTPs($entradaB, 'LONG', $hvn, $liqClusters, $poc, $pdh, $pdl, $stopB);

            $risco = ($entradaB - $stopB) / max($entradaB, 0.0001);
            $alav = max(min(self::RISCO_MAX_CONTA / max($risco, 0.001), $alavMax), 1.0);
            $liq = self::calcularLiquidacao($entradaB, 'LONG', $alav);
            $t = 0;
            while ($liq > 0 && $stopB <= $liq * (1 + self::MARGEM_SEG_LIQ) && $alav > 1.0 && $t < 20) {
                $alav -= 0.5;
                $liq = self::calcularLiquidacao($entradaB, 'LONG', $alav);
                $t++;
            }
            $alav = max($alav, 1.0);
            $liq = self::calcularLiquidacao($entradaB, 'LONG', $alav);

            $rr1 = $entradaB !== $stopB ? ($tps['tp1'] - $entradaB) / max($entradaB - $stopB, 0.0001) : 0;

            return [
                'entrada' => round($entradaB, 4),
                'stop' => round($stopB, 4),
                'tp1' => round($tps['tp1'], 4),
                'tp2' => round($tps['tp2'], 4),
                'tp3' => round($tps['tp3'], 4),
                'alavancagem' => round($alav, 1),
                'liquidacao' => $liq > 0 ? round($liq, 4) : 'N/A (1x)',
                'riscoPct' => round($risco * 100, 2),
                'rr1' => round($rr1, 2),
                'verificacao' => $stopB < ($liq > 0 ? $liq * (1 + self::MARGEM_SEG_LIQ) : INF) ? '✓ SEGURO' : '✗ INSEGURO',
                'tipo' => 'PULLBACK',
                'descricao' => 'Aguardar pullback ao HVN com confluência de Wyckoff (spring/test), CVD divergente e pressão compradora no orderbook para confirmar entrada técnica no nível estrutural.',
            ];
        }

        // SHORT: entrada no primeiro HVN acima do preço (fallback POC)
        $hvnAcima = array_filter($hvn, fn($h) => $h > $preco);
        $entradaB = !empty($hvnAcima) ? min($hvnAcima) : ($poc > 0 && $poc > $preco ? $poc : $preco + ($atr * 0.5));

        // Garantir que entrada B está acima do preço atual
        if ($entradaB <= $preco) {
            $entradaB = $preco + ($atr * 0.5);
        }

        // Stop com multiplicador ATR reduzido (0.8x)
        $stopResultB = self::calcularStopShort($entradaB, $hvn, $elementosVisuais, $pdh, $poc, $atr, $atrMultB);
        $stopB = $stopResultB['stop'];

        // TPs recalculados a partir da entrada B
        $tps = self::calcularTPs($entradaB, 'SHORT', $hvn, $liqClusters, $poc, $pdh, $pdl, $stopB);

        $risco = ($stopB - $entradaB) / max($entradaB, 0.0001);
        $alav = max(min(self::RISCO_MAX_CONTA / max($risco, 0.001), $alavMax), 1.0);
        $liq = self::calcularLiquidacao($entradaB, 'SHORT', $alav);
        $t = 0;
        while ($liq < INF && $stopB >= $liq * (1 - self::MARGEM_SEG_LIQ) && $alav > 1.0 && $t < 20) {
            $alav -= 0.5;
            $liq = self::calcularLiquidacao($entradaB, 'SHORT', $alav);
            $t++;
        }
        $alav = max($alav, 1.0);
        $liq = self::calcularLiquidacao($entradaB, 'SHORT', $alav);

        $rr1 = $stopB !== $entradaB ? ($entradaB - $tps['tp1']) / max($stopB - $entradaB, 0.0001) : 0;

        return [
            'entrada' => round($entradaB, 4),
            'stop' => round($stopB, 4),
            'tp1' => round($tps['tp1'], 4),
            'tp2' => round($tps['tp2'], 4),
            'tp3' => round($tps['tp3'], 4),
            'alavancagem' => round($alav, 1),
            'liquidacao' => $liq < INF ? round($liq, 4) : 'N/A (1x)',
            'riscoPct' => round($risco * 100, 2),
            'rr1' => round($rr1, 2),
            'verificacao' => $stopB > ($liq < INF ? $liq * (1 - self::MARGEM_SEG_LIQ) : 0) ? '✓ SEGURO' : '✗ INSEGURO',
            'tipo' => 'PULLBACK',
            'descricao' => 'Aguardar repique ao HVN com confluência de Wyckoff (UTAD/upthrust), CVD divergente e pressão vendedora no orderbook para confirmar entrada técnica no nível estrutural.',
        ];
    }

    /**
     * Valida se a direção do setup é consistente com o viés do score.
     * Adiciona campo alertaContradicao quando há inconsistência.
     */
    private static function validarDirecao(string $direcao, int $score, string $scoreVies): array
    {
        $consistente = true;
        $motivo = 'Direção alinhada com o score.';
        $alertaContradicao = null;

        // Se score < 45 e direção é LONG → inconsistência
        if ($score < 45 && $direcao === 'LONG') {
            $consistente = false;
            $motivo = "Score {$score}/100 indica viés {$scoreVies}, mas setup é LONG. Operar com cautela ou aguardar confirmação.";
            $alertaContradicao = "Contradição direcional: score {$score} (bearish) vs setup LONG.";
        }

        // Se score > 54 e direção é SHORT → inconsistência
        if ($score > 54 && $direcao === 'SHORT') {
            $consistente = false;
            $motivo = "Score {$score}/100 indica viés {$scoreVies}, mas setup é SHORT. Operar com cautela ou aguardar confirmação.";
            $alertaContradicao = "Contradição direcional: score {$score} (bullish) vs setup SHORT.";
        }

        return [
            'consistente' => $consistente,
            'direcaoSetup' => $direcao,
            'scoreVies' => $scoreVies,
            'motivo' => $motivo,
            'alertaContradicao' => $alertaContradicao,
        ];
    }

    /**
     * Valida consistência geométrica do setup (entrada vs stop vs direção).
     * LONG: entrada > stop; SHORT: entrada < stop.
     *
     * @return array ['valido' => bool, 'motivo' => string|null]
     */
    private static function validarGeometria(float $entrada, float $stop, string $direcao): array
    {
        if ($direcao === 'LONG' && $entrada <= $stop) {
            return [
                'valido' => false,
                'motivo' => 'Contradição geométrica: entrada abaixo do stop para LONG',
            ];
        }

        if ($direcao === 'SHORT' && $entrada >= $stop) {
            return [
                'valido' => false,
                'motivo' => 'Contradição geométrica: entrada acima do stop para SHORT',
            ];
        }

        return ['valido' => true, 'motivo' => null];
    }

    /**
     * Calcula Risk-Reward ratio.
     */
    private static function calcularRR(float $entrada, float $stop, float $tp1): float
    {
        if ($entrada === $stop) {
            return 0;
        }
        $risco = abs($entrada - $stop);
        $retorno = abs($tp1 - $entrada);
        return $risco > 0 ? $retorno / $risco : 0;
    }

    /**
     * Limita alavancagem máxima por faixa de score.
     * score < 50 → max 2x; 50-64 → max 3x; 65-74 → max 5x; >= 75 → max 10x
     */
    private static function limitarAlavancagemPorScore(int $score): float
    {
        if ($score < 50) {
            return 2.0;
        }
        if ($score < 65) {
            return 3.0;
        }
        if ($score < 75) {
            return 5.0;
        }
        return 10.0;
    }

    /**
     * Recalcula setup completo por alavancagem: liquidação, risco, RR, tamanhoSugerido.
     * Loop de redução 0.5 quando stop dentro da margem 5% da liquidação.
     * Alavancagem 1x → liquidacao "N/A (1x)".
     */
    private static function recalcularPorAlavancagem(array $setup, float $alavancagem, string $direcao): array
    {
        $entrada = $setup['entrada'];
        $stop = $setup['stop'];
        $tp1 = $setup['tp1'];

        if ($entrada <= 0) {
            return $setup;
        }

        $alav = $alavancagem;

        // Loop de redução: reduzir 0.5 enquanto stop dentro da margem 5% da liquidação
        $t = 0;
        while ($alav > 1.0 && $t < 20) {
            $liq = self::calcularLiquidacao($entrada, $direcao, $alav);

            if ($direcao === 'LONG') {
                // Stop must be safely above liquidation
                if ($liq > 0 && $stop <= $liq * (1 + self::MARGEM_SEG_LIQ)) {
                    $alav -= 0.5;
                } else {
                    break;
                }
            } else {
                // SHORT: stop must be safely below liquidation
                if ($liq < INF && $stop >= $liq * (1 - self::MARGEM_SEG_LIQ)) {
                    $alav -= 0.5;
                } else {
                    break;
                }
            }
            $t++;
        }
        $alav = max($alav, 1.0);

        $liq = self::calcularLiquidacao($entrada, $direcao, $alav);

        // Alavancagem 1x → liquidação nula
        if ($alav <= 1.0) {
            $liquidacaoStr = 'N/A (1x)';
        } else {
            $liquidacaoStr = $direcao === 'LONG'
                ? ($liq > 0 ? round($liq, 4) : 'N/A (1x)')
                : ($liq < INF ? round($liq, 4) : 'N/A (1x)');
        }

        $riscoPct = abs($entrada - $stop) / max($entrada, 0.0001) * 100;
        $rr = self::calcularRR($entrada, $stop, $tp1);

        // Formato: "$margem (Nx) = $total → quantidade | Risco: $USD"
        $margem = 100.0; // Margem base padrão
        $total = $margem * $alav;
        $quantidade = $total / max($entrada, 0.0001);
        $riscoUsd = ($riscoPct / 100) * $total;

        $tamanhoSugerido = sprintf(
            '$%.0f (%.1fx) = $%.2f → %.6f | Risco: $%.2f',
            $margem,
            $alav,
            $total,
            $quantidade,
            $riscoUsd
        );

        // Verificação de segurança
        if ($direcao === 'LONG') {
            $verificacao = ($alav <= 1.0 || ($liq > 0 && $stop > $liq * (1 + self::MARGEM_SEG_LIQ)))
                ? '✓ SEGURO' : '✗ INSEGURO';
        } else {
            $verificacao = ($alav <= 1.0 || ($liq < INF && $stop < $liq * (1 - self::MARGEM_SEG_LIQ)))
                ? '✓ SEGURO' : '✗ INSEGURO';
        }

        $setup['alavancagem'] = round($alav, 1);
        $setup['liquidacao'] = $liquidacaoStr;
        $setup['riscoPct'] = round($riscoPct, 2);
        $setup['rr1'] = round($rr, 2);
        $setup['verificacao'] = $verificacao;
        $setup['tamanhoSugerido'] = $tamanhoSugerido;

        return $setup;
    }

    private static function zonaInteresse(string $regime, float $preco, float $atr, float $poc, array $hvn): array
    {
        if (str_contains($regime, 'BULLISH') || str_contains($regime, 'UP')) {
            return [
                'tipo' => 'PULLBACK',
                'zona' => round(max($poc, $preco - 1.5 * $atr), 4) . ' - ' . round($preco - 0.5 * $atr, 4),
                'invalidacao' => 'Abaixo de ' . round($poc * 0.95, 4),
            ];
        }
        if (str_contains($regime, 'BEARISH') || str_contains($regime, 'DOWN')) {
            $maxHvn = !empty($hvn) ? max($hvn) : $preco * 1.10;
            return [
                'tipo' => 'REPICO',
                'zona' => round($preco + 0.5 * $atr, 4) . ' - ' . round(min($maxHvn, $preco + 1.5 * $atr), 4),
                'invalidacao' => 'Acima de ' . round($maxHvn * 1.05, 4),
            ];
        }
        return [
            'tipo' => 'RANGE',
            'zona' => 'Aguardar rompimento de ' . round($poc, 4),
            'invalidacao' => null,
        ];
    }
}
