<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

use App\Services\CacheManager;
use App\Models\OiHistorico;

class GeminiAnalysisService
{
    public function __construct(
        private ExchangeRouter $exchangeRouter,
        private BinanceService $binance,
        private YahooFinanceService $yahoo,
        private TechnicalAnalysisService $techAnalysis,
        private ScoringService $scoring,
        private ContextBuilderService $contextBuilder,
        private AlternativeService $alternative,
        private CoinGeckoService $coinGecko,
    ) {}

    public function analisar(string $symbol, string $timeframe, int $leverage, string $imageBase64, float $entryValue = 0): array
    {
        // 1. Buscar candles
        $candles = [];
        try {
            $candles = $this->binance->getCandles($symbol, $timeframe, 500);
            if (!is_array($candles)) { $candles = []; }
        } catch (\Exception $e) {
            Log::error("GeminiAnalysis: Falha ao buscar candles", ["symbol" => $symbol, "error" => $e->getMessage()]);
        }

        // 2. Buscar dados macro (cache 5min)
        $macro = ["vix" => 0, "dxy_variacao" => 0, "sp500_variacao" => 0];
        foreach (["vix" => "^VIX", "dxy" => "DX-Y.NYB", "sp500" => "^GSPC"] as $key => $ticker) {
            try {
                $quote = $this->yahoo->getQuote($ticker);
                $price = $quote["price"] ?? 0;
                $prevClose = $quote["previous_close"] ?? 0;
                $changePct = $prevClose > 0 ? round((($price - $prevClose) / $prevClose) * 100, 2) : 0;
                if ($key === "vix") $macro["vix"] = $price;
                else $macro["{$key}_variacao"] = $changePct;
            } catch (\Exception $e) {
                Log::warning("GeminiAnalysis: Falha ao buscar {$ticker}", ["error" => $e->getMessage()]);
            }
        }

        // 3. Buscar derivativos via ExchangeRouter (após extrair elementos visuais)
        // Nota: $elementosVisuais é necessário para detectar exchange via OCR
        $derivativos = ["oi" => 0, "funding_rate" => "0", "long_short_ratio" => 50, "cvd" => ["delta" => 0, "imbalance" => 0], "oi_variacao" => 0];
        $alertaHibrido = false;
        $avisoLiquidez = false;

        // 3.1 Extrair elementos visuais desenhados
        $elementosVisuais = [];
        try {
            $elementosVisuais = $this->extrairElementosVisuais($imageBase64);
            // LOG DEBUG: OCR Visual completo
            Log::info("DEBUG_OCR: Resultado extrairElementosVisuais", [
                "symbol" => $symbol,
                "suportes" => $elementosVisuais['suportes'] ?? [],
                "resistencias" => $elementosVisuais['resistencias'] ?? [],
                "padroes_graficos" => $elementosVisuais['padroes_graficos'] ?? [],
                "indicadores_visiveis" => $elementosVisuais['indicadores_visiveis'] ?? [],
                "linhas_tendencia" => $elementosVisuais['linhas_tendencia'] ?? [],
                "fibonacci" => $elementosVisuais['fibonacci'] ?? [],
                "anotacoes" => $elementosVisuais['anotacoes'] ?? [],
            ]);
        } catch (\Throwable $e) {
            Log::warning("GeminiAnalysis: Falha na extracao visual", ["error" => $e->getMessage()]);
        }

        // 3.2 Buscar derivativos com ExchangeRouter
        try {
            $corretora = $this->exchangeRouter->detectar($elementosVisuais['exchange'] ?? null);
            $routerResult = $this->exchangeRouter->buscar($symbol, $corretora);

            $oiVariacao = $this->calcularOiVariacao($symbol, $corretora, (float) $routerResult['oi']);

            $derivativos = [
                "oi" => $routerResult['oi'],
                "funding_rate" => $routerResult['funding_rate'],
                "long_short_ratio" => $routerResult['long_short_ratio'],
                "cvd" => $routerResult['cvd'],
                "oi_variacao" => $oiVariacao,
            ];

            $alertaHibrido = $routerResult['alerta_hibrido'];
            $avisoLiquidez = $routerResult['aviso_liquidez'];

            // Se aviso_liquidez e fallback Binance também OI=0, zerar bloco
            if ($avisoLiquidez && $routerResult['oi'] == 0) {
                $derivativos = [
                    "oi" => 0,
                    "funding_rate" => "0",
                    "long_short_ratio" => 50,
                    "cvd" => ["delta" => 0, "imbalance" => 0],
                    "oi_variacao" => 0,
                ];
            }
        } catch (\Exception $e) {
            Log::warning("GeminiAnalysis: Falha ao buscar derivativos", ["error" => $e->getMessage()]);
        }

        // 4. Calcular indicadores
        $indicadores = [];
        try {
            if (!empty($candles) && is_array($candles)) {
                $indicadores = $this->techAnalysis->calcular($candles);
            }
        } catch (\Throwable $e) {
            Log::error("GeminiAnalysis: Erro ao calcular indicadores", ["error" => $e->getMessage()]);
        }

        // LOG DEBUG: Indicadores técnicos calculados (EMAs, RSI, ADX, ATR, MACD)
        Log::info("DEBUG_INDICADORES: Resultado TechnicalAnalysis", [
            "symbol" => $symbol,
            "preco" => $indicadores['preco'] ?? 0,
            "ema21" => $indicadores['ema21'] ?? null,
            "ema50" => $indicadores['ema50'] ?? null,
            "ema200" => $indicadores['ema200'] ?? null,
            "ema21_subindo" => $indicadores['ema21_subindo'] ?? false,
            "ema50_subindo" => $indicadores['ema50_subindo'] ?? false,
            "ema200_subindo" => $indicadores['ema200_subindo'] ?? false,
            "rsi" => $indicadores['rsi'] ?? null,
            "divergencia_rsi" => $indicadores['divergencia_rsi'] ?? "NENHUMA",
            "adx" => $indicadores['adx'] ?? null,
            "plus_di" => $indicadores['plus_di'] ?? null,
            "minus_di" => $indicadores['minus_di'] ?? null,
            "atr" => $indicadores['atr'] ?? null,
            "macd" => $indicadores['macd'] ?? null,
            "macd_signal" => $indicadores['macd_signal'] ?? null,
            "macd_histograma" => $indicadores['macd_histograma'] ?? null,
            "compressao" => $indicadores['compressao'] ?? [],
            "fontes" => $indicadores['fontes'] ?? [],
        ]);

        // 4.2 Padrão de Candle
        $padraoCandle = "NENHUM";
        try {
            if (!empty($candles)) {
                $padraoCandle = $this->techAnalysis->detectarPadraoCandle($candles);
            }
        } catch (\Throwable $e) {
            Log::warning("GeminiAnalysis: Erro ao detectar padrao candle", ["error" => $e->getMessage()]);
        }

        // 4.3 Divergência CVD
        $divergenciaCVD = "NENHUMA";
        try {
            $cvdData = $derivativos['cvd']['series'] ?? [];
            if (!empty($candles) && !empty($cvdData)) {
                $divergenciaCVD = $this->techAnalysis->calcularDivergenciaCVD($candles, $cvdData);
            }
        } catch (\Throwable $e) {
            Log::warning("GeminiAnalysis: Erro ao calcular divergencia CVD", ["error" => $e->getMessage()]);
        }

        // 4.4 Wyckoff completo
        $wyckoffResult = ['fase' => 'INDETERMINADO', 'evento' => null, 'narrativa' => 'Dados insuficientes para analise Wyckoff.', 'gatilho' => 'N/A', 'range' => ['teto' => 0, 'suporte' => 0]];
        try {
            if (!empty($candles)) {
                $wyckoffResult = $this->techAnalysis->detectarWyckoff($candles);
            }
        } catch (\Throwable $e) {
            Log::warning("GeminiAnalysis: Erro ao detectar Wyckoff", ["error" => $e->getMessage()]);
        }

        // LOG DEBUG: Wyckoff detectado
        Log::info("DEBUG_WYCKOFF: Resultado detectarWyckoff", [
            "symbol" => $symbol,
            "fase" => $wyckoffResult['fase'],
            "evento" => $wyckoffResult['evento'],
            "gatilho" => $wyckoffResult['gatilho'],
            "range_teto" => $wyckoffResult['range']['teto'] ?? 0,
            "range_suporte" => $wyckoffResult['range']['suporte'] ?? 0,
        ]);

        // 5. Zonas estruturais
        $zonas = $this->calcularZonas($candles, $symbol, $timeframe);

        // LOG DEBUG: Zonas estruturais (POC, HVN, LVN, PDH, PDL)
        Log::info("DEBUG_ZONAS: Resultado calcularZonas", [
            "symbol" => $symbol,
            "poc" => $zonas['poc'] ?? 0,
            "hvn" => $zonas['hvn'] ?? [],
            "lvn" => $zonas['lvn'] ?? [],
            "pdh" => $zonas['pdh'] ?? 0,
            "pdl" => $zonas['pdl'] ?? 0,
            "pwh" => $zonas['pwh'] ?? 0,
            "pwl" => $zonas['pwl'] ?? 0,
        ]);

        // 5.0.1 Sobrepor zonas com POC/HVN/LVN do LuxAlgo via OCR (precisao visual prevalece)
        if (!empty($elementosVisuais['poc']))  $zonas['poc'] = (float) $elementosVisuais['poc'];
        if (!empty($elementosVisuais['hvn']))  $zonas['hvn'] = array_map('floatval', $elementosVisuais['hvn']);
        if (!empty($elementosVisuais['lvn']))  $zonas['lvn'] = array_map('floatval', $elementosVisuais['lvn']);

        // 5.1 Multi-timeframe
        $multiTimeframe = $this->calcularMultiTimeframe($symbol, $timeframe);

        // 5.2 Buscar dados públicos (Fear & Greed + BTC Dominância)
        $fearGreedReal = 50;
        try {
            $fgData = $this->alternative->getCurrentFearGreed();
            if ($fgData && isset($fgData['value'])) {
                $fearGreedReal = (int) $fgData['value'];
            }
        } catch (\Throwable $e) {
            Log::warning("GeminiAnalysis: Falha ao buscar Fear & Greed", ["error" => $e->getMessage()]);
        }

        $btcDominanciaReal = 0;
        try {
            $btcDom = $this->coinGecko->getBtcDominance();
            if ($btcDom !== null) {
                $btcDominanciaReal = round($btcDom, 2);
            }
        } catch (\Throwable $e) {
            Log::warning("GeminiAnalysis: Falha ao buscar BTC Dominância", ["error" => $e->getMessage()]);
        }

        // 6. Calcular score (com try/catch)
        $scoreInput = [
            "preco" => $indicadores["preco"] ?? 0,
            "ema21" => $indicadores["ema21"] ?? null,
            "ema50" => $indicadores["ema50"] ?? null,
            "ema200" => $indicadores["ema200"] ?? null,
            "ema21_subindo" => $indicadores["ema21_subindo"] ?? false,
            "ema50_subindo" => $indicadores["ema50_subindo"] ?? false,
            "ema200_subindo" => $indicadores["ema200_subindo"] ?? false,
            "rsi" => $indicadores["rsi"] ?? null,
            "divergencia_rsi" => $indicadores["divergencia_rsi"] ?? "NENHUMA",
            "adx" => $indicadores["adx"] ?? null,
            "adx_subindo" => $indicadores["adx_subindo"] ?? false,
            "macd_acima_signal" => $indicadores["macd_acima_signal"] ?? false,
            "histograma_subindo" => $indicadores["histograma_subindo"] ?? false,
            "macd_cruza_zero" => $indicadores["macd_cruza_zero"] ?? null,
            "atr" => $indicadores["atr"] ?? null,
            "compressao_detectada" => $indicadores["compressao"]["detectada"] ?? false,
            "nivel_compressao" => $indicadores["compressao"]["nivel"] ?? "NENHUMA",
            "preco_subindo" => $indicadores["preco_subindo"] ?? false,
            "funding_rate" => ($derivativos["funding_rate"] ?? null) !== "0" ? ($derivativos["funding_rate"] ?? null) : null,
            "oi_subindo" => ($derivativos["oi_variacao"] ?? null) !== null && $derivativos["oi_variacao"] != 0
                ? ($derivativos["oi_variacao"] > 0)
                : null,
            "long_short_ratio" => $derivativos["long_short_ratio"] ?? null,
            "cvd_slope" => ($derivativos["cvd"]["delta"] ?? null) != 0 ? ($derivativos["cvd"]["delta"] ?? null) : null,
            "book_imbalance_ratio" => ($derivativos["cvd"]["imbalance"] ?? null) != 0 ? ($derivativos["cvd"]["imbalance"] ?? null) : null,
            "divergencia_cvd" => $divergenciaCVD,
            "cluster_liquidacao_acima" => $zonas["pdh"] ?? null,
            "cluster_liquidacao_abaixo" => $zonas["pdl"] ?? null,
            // Macro fields — kept for flags only (não pontuam no ScoringService 55/45)
            "vix" => $macro["vix"] ?? null,
            "dxy_variacao" => $macro["dxy_variacao"] ?? null,
            "sp500_variacao" => $macro["sp500_variacao"] ?? null,
            "btc_dominancia_variacao" => $btcDominanciaReal,
            "usdt_dominancia_variacao" => 0,
            "correlacao_btc_descorrelacao" => false,
            "correlacao_btc_tipo" => "",
            "fear_greed" => $fearGreedReal,
            "geopolitica_score" => 0,
            "sentimento_moeda_score" => $this->calcularSentimentoMoeda($fearGreedReal, $btcDominanciaReal, $derivativos),
        ];

        try {
            $score = $this->scoring->calcular($scoreInput);
            Log::info("GeminiAnalysis: Score={$score["scoreFinal"]} vies={$score["vies"]} confiabilidade={$score["confiabilidade"]} flags=" . implode(",", $score["flags"]));
        } catch (\Throwable $e) {
            Log::error("GeminiAnalysis: Erro no scoring", ["error" => $e->getMessage()]);
            $score = ["scoreFinal" => 50, "vies" => "NEUTRO", "confiabilidade" => "BAIXA", "blocoTecnico" => ["pontos" => 0, "maximo" => 55, "percentual" => 0], "blocoDerivativos" => ["pontos" => 0, "maximo" => 45, "percentual" => 0], "flags" => []];
        }

        // 7. Montar contexto
        $contexto = "";
        try {
            $contexto = $this->contextBuilder->build(
                $indicadores,
                $derivativos,
                $macro,
                $score,
                $zonas,
                $indicadores['volume'] ?? [],
                $wyckoffResult,
                $elementosVisuais
            );
        } catch (\Throwable $e) {
            Log::error("GeminiAnalysis: Erro ao montar contexto", ["error" => $e->getMessage()]);
        }

        // 7.1 Injecoes extras no contexto
        if (!empty($indicadores["compressao"]["detectada"])) {
            $c = $indicadores["compressao"];
            $contexto .= "\n\nCOMPRESSAO DE VOLATILIDADE VIA CALCULO LOCAL:\n";
            $contexto .= "- Compressao Ativa: SIM (Nivel: {$c["nivel"]})\n";
            $contexto .= "- Probabilidade de Rompimento Iminente: {$c["probabilidade"]}%\n";
            $contexto .= "\nINSTRUCAO OBRIGATORIA PARA SETUP: O mercado esta em compressao de volatilidade (acumulando energia). O setup deve considerar entrada agressiva na direcao do rompimento, stop curto, alvos amplos.";
        }

        // 7.2 Verificacao de contexto vazio
        if (empty(trim($contexto))) {
            Log::warning("GeminiAnalysis: Contexto vazio, usando fallback", ["symbol" => $symbol]);
            $contexto = "Os dados de mercado nao estavam disponiveis no momento da analise. Prossiga a interpretacao com base no grafico e em informacoes visuais.";
        }

        // 8. Montar prompt
        $prompt = $this->buildPrompt(
            $symbol,
            $timeframe,
            $leverage,
            $contexto,
            $entryValue,
            $elementosVisuais,
            $macro,
            $fearGreedReal,
            $btcDominanciaReal,
            $wyckoffResult
        );

        // 9. Chamar Gemini (cada análise é fresca — dados individuais já são cacheados por endpoint)
        $geminiResult = $this->callGemini($imageBase64, $prompt);

        // 10. Montar resposta
        $result = $this->buildTradeSetup($geminiResult, $indicadores, $score, $zonas, $macro, $derivativos, $multiTimeframe, $symbol, $timeframe, $leverage, $candles);

        // 10.1 Incluir Wyckoff no resultado
        $result['wyckoff'] = $wyckoffResult;

        // 11. Override com MotorExecucao matematico
        $precoAtual = $indicadores['preco'] ?? 0;

        // Fallback: tentar pegar preço do último candle se indicadores não tem
        if ($precoAtual <= 0 && !empty($candles)) {
            $lastCandle = end($candles);
            if (is_array($lastCandle) && isset($lastCandle[4])) {
                $precoAtual = (float) $lastCandle[4];
            }
        }

        // Fallback 2: buscar preço atual via ticker API
        if ($precoAtual <= 0) {
            try {
                $precoAtual = $this->binance->getCurrentPrice($symbol);
            } catch (\Throwable $e) {
                Log::warning("GeminiAnalysis: Fallback de preço falhou", ["symbol" => $symbol, "error" => $e->getMessage()]);
            }
        }

        $hvn = $zonas['hvn'] ?? [];
        $lvn = $zonas['lvn'] ?? [];
        $poc = $zonas['poc'] ?? $precoAtual;

        // Buscar clusters de liquidação reais via BinanceService
        $liqClusters = ['above' => [], 'below' => []];
        try {
            if ($precoAtual > 0) {
                $liqClusters = $this->binance->getLiquidacoes($symbol, $precoAtual);
            }
        } catch (\Throwable $e) {
            Log::warning("GeminiAnalysis: Falha ao buscar liquidacoes", ["symbol" => $symbol, "error" => $e->getMessage()]);
        }

        $direcaoSetup = $result['direcaoProvavel'] ?? 'LONG';
        $scoreVies = $score['vies'] ?? 'NEUTRO';

        // Validação de direção: se score sugere direção oposta, usar direção do score
        if ($this->direcaoConflitante($direcaoSetup, $scoreVies)) {
            Log::info("GeminiAnalysis: Direção conflitante", [
                "direcaoSetup" => $direcaoSetup,
                "scoreVies" => $scoreVies,
                "scoreFinal" => $score['scoreFinal'] ?? 50,
            ]);
            // Score predomina sobre interpretação Gemini
            $direcaoSetup = str_contains($scoreVies, 'SHORT') ? 'SHORT' : (str_contains($scoreVies, 'LONG') ? 'LONG' : $direcaoSetup);
        }

        $setupMatematico = \App\Services\MotorExecucaoService::gerarSetup(
            $precoAtual,
            $direcaoSetup,
            $result['scoreProbabilidade'] ?? 50,
            $result['confianca'] ?? 50,
            $indicadores['atr'] ?? 100,
            $result['regime'] ?? 'NEUTRO',
            $hvn, $lvn, $liqClusters, $poc,
            $elementosVisuais,
            $scoreVies
        );

        // LOG DEBUG: Input e output do MotorExecucao
        Log::info("DEBUG_MOTOR_INPUT: Parametros gerarSetup", [
            "symbol" => $symbol,
            "precoAtual" => $precoAtual,
            "direcaoSetup" => $direcaoSetup,
            "score" => $result['scoreProbabilidade'] ?? 50,
            "confianca" => $result['confianca'] ?? 50,
            "atr" => $indicadores['atr'] ?? 100,
            "regime" => $result['regime'] ?? 'NEUTRO',
            "hvn_count" => count($hvn),
            "hvn_valores" => array_slice($hvn, 0, 5),
            "lvn_count" => count($lvn),
            "lvn_valores" => array_slice($lvn, 0, 5),
            "liqClusters_above" => array_slice($liqClusters['above'] ?? [], 0, 3),
            "liqClusters_below" => array_slice($liqClusters['below'] ?? [], 0, 3),
            "poc" => $poc,
            "elementosVisuais_suportes" => $elementosVisuais['suportes'] ?? [],
            "elementosVisuais_resistencias" => $elementosVisuais['resistencias'] ?? [],
            "scoreVies" => $scoreVies,
        ]);
        Log::info("DEBUG_MOTOR_OUTPUT: Resultado gerarSetup", [
            "symbol" => $symbol,
            "acao" => $setupMatematico['acao'] ?? null,
            "motivo" => $setupMatematico['motivo'] ?? null,
            "entrada" => $setupMatematico['setup']['entrada'] ?? 0,
            "stop" => $setupMatematico['setup']['stop'] ?? 0,
            "tp1" => $setupMatematico['setup']['tp1'] ?? 0,
            "tp2" => $setupMatematico['setup']['tp2'] ?? 0,
            "tp3" => $setupMatematico['setup']['tp3'] ?? 0,
            "alavancagem" => $setupMatematico['setup']['alavancagem'] ?? 0,
            "rr1" => $setupMatematico['setup']['rr1'] ?? 0,
            "hierarquiaStop" => $setupMatematico['setup']['hierarquiaStop'] ?? 'N/A',
            "verificacao" => $setupMatematico['setup']['verificacao'] ?? 'N/A',
            "planoB_entrada" => $setupMatematico['planoB']['entrada'] ?? null,
            "validacaoDirecao" => $setupMatematico['validacaoDirecao'] ?? [],
        ]);

        $result['execucao'] = $setupMatematico;

        // C-03: Sobrescrever entradaSugerida com valores reais do Motor (não Gemini)
        $result['entradaSugerida']['planoA']          = $setupMatematico['setup']['entrada']      ?? 0;
        $result['entradaSugerida']['descricaoPlanoA'] = $setupMatematico['motivo']                ?? '';
        $result['entradaSugerida']['planoB']          = $setupMatematico['planoB']['entrada']     ?? 0;
        $result['entradaSugerida']['descricaoPlanoB'] = $setupMatematico['planoB']['descricao']   ?? '';

        // 12. Calcular posicao — fallback $100 demo margin se entryValue <= 0
        $margemBase = ($entryValue > 0) ? $entryValue : 100;
        $valorTotal = $margemBase * $leverage;
        $precoEntrada = (float) ($setupMatematico['setup']['entrada'] ?? 0);

        if ($precoEntrada > 0) {
            $quantidade = $valorTotal / $precoEntrada;
            $riscoStop = abs($precoEntrada - (float) ($setupMatematico['setup']['stop'] ?? $precoEntrada));
            $riscoUSD = ($riscoStop / $precoEntrada) * $valorTotal;
            $result['execucao']['setup']['tamanhoSugerido'] = "\${$margemBase} ({$leverage}x) = $" . number_format($valorTotal, 2) . " → " . round($quantidade, 6) . " {$symbol} | Risco: $" . number_format($riscoUSD, 2);
        } else {
            // Sem preco de entrada disponivel — exibir apenas valor total calculado
            $result['execucao']['setup']['tamanhoSugerido'] = "\${$margemBase} ({$leverage}x) = $" . number_format($valorTotal, 2);
        }

        // 13. Narrativa separada
        $narrativas              = $this->gerarNarrativa($symbol, $indicadores, $score, $setupMatematico, $wyckoffResult, $derivativos, $elementosVisuais);
        $result['narrativa']     = is_array($narrativas) ? ($narrativas['analiseTecnica'] ?? '') : $narrativas;
        $result['rationalScore'] = is_array($narrativas) ? ($narrativas['rationalScore'] ?? '') : '';

        // 14. Incluir alertas do ExchangeRouter na resposta final
        if ($alertaHibrido) {
            $result['alerta_hibrido'] = true;
        }
        if ($avisoLiquidez) {
            $result['aviso_liquidez'] = "O ativo na corretora detectada não possui liquidez suficiente em derivativos. Dados obtidos via fallback Binance.";
        }

        Log::info("GeminiAnalysis: Analise completa", ["symbol" => $symbol, "timeframe" => $timeframe, "score" => $result["scoreProbabilidade"] ?? 0, "direcao" => $result["direcaoProvavel"] ?? "N/A"]);

        return $result;
    }

    /**
     * C-05: Mapa de timeframes corrigido.
     * 1M removido de análises < 1W. Threshold mínimo de candles por TF.
     */
    private function calcularMultiTimeframe(string $symbol, string $currentTf): array
    {
        $map = [
            '1m'  => ['5m',  '15m'],
            '5m'  => ['15m', '1h'],
            '15m' => ['1h',  '4h'],  '15M' => ['1h',  '4h'],
            '30m' => ['1h',  '4h'],
            '1h'  => ['4h',  '1d'],  '1H'  => ['4h',  '1d'],
            '2h'  => ['4h',  '1d'],  '2H'  => ['4h',  '1d'],
            '4h'  => ['1d'],          '4H'  => ['1d'],
            '6h'  => ['1d'],          '6H'  => ['1d'],
            '12h' => ['1d'],          '12H' => ['1d'],
            '1d'  => ['1w'],          '1D'  => ['1w'],
            '1w'  => ['1M'],          '1W'  => ['1M'],
        ];

        $hTfs = $map[$currentTf] ?? $map[strtolower($currentTf)] ?? [];
        $result = [];

        $minCandles = function (string $tf): int {
            return match (strtolower($tf)) {
                '1w'    => 30,
                '1m'    => 24,
                default => 50,
            };
        };

        foreach ($hTfs as $tf) {
            try {
                $data   = $this->binance->getCandles($symbol, $tf, 60);
                $minReq = $minCandles($tf);

                if (!is_array($data) || count($data) < $minReq) {
                    $result[] = ['timeframe' => strtoupper($tf), 'bias' => 'N/D'];
                    continue;
                }

                $closes    = array_map(fn($k) => (float) $k[4], $data);
                $lastClose = end($closes);

                $rsi  = $this->techAnalysis->rsi($closes, 14);
                $ema21 = $this->techAnalysis->ema($closes, 21);
                $ema50 = $this->techAnalysis->ema($closes, 50);

                if ($rsi === null || $ema21 === null || $ema50 === null) {
                    $result[] = ['timeframe' => strtoupper($tf), 'bias' => 'N/D'];
                    continue;
                }

                $score = 0;
                if ($rsi > 50)           $score += 1;
                elseif ($rsi < 50)       $score -= 1;
                if ($lastClose > $ema21) $score += 1;
                elseif ($lastClose < $ema21) $score -= 1;
                if ($lastClose > $ema50) $score += 1;
                elseif ($lastClose < $ema50) $score -= 1;

                $bias = $score >= 2 ? 'BULLISH' : ($score <= -2 ? 'BEARISH' : 'NEUTRO');

                $result[] = ['timeframe' => strtoupper($tf), 'bias' => $bias];
            } catch (\Throwable $e) {
                $result[] = ['timeframe' => strtoupper($tf), 'bias' => 'N/D'];
            }
        }

        return $result;
    }

    private function calcularZonas(array $candles, string $symbol, string $timeframe): array
    {
        $zonas = ["pdh" => 0, "pdl" => 0, "pwh" => 0, "pwl" => 0, "poc" => 0, "hvn" => [], "lvn" => []];

        try {
            $dKlines = $this->binance->getCandles($symbol, "1d", 3);
            if (is_array($dKlines) && count($dKlines) >= 2) {
                $prevDay = $dKlines[count($dKlines) - 2];
                $zonas["pdh"] = (float) $prevDay[2];
                $zonas["pdl"] = (float) $prevDay[3];
            }
        } catch (\Exception $e) {}

        try {
            $wKlines = $this->binance->getCandles($symbol, "1w", 3);
            if (is_array($wKlines) && count($wKlines) >= 2) {
                $prevWeek = $wKlines[count($wKlines) - 2];
                $zonas["pwh"] = (float) $prevWeek[2];
                $zonas["pwl"] = (float) $prevWeek[3];
            }
        } catch (\Exception $e) {}

        // Volume Profile — POC, HVN, LVN
        try {
            if (!empty($candles)) {
                $vp = $this->techAnalysis->calcularVolumeProfile($candles);
                $zonas["poc"] = $vp["poc"] ?? 0;
                $zonas["hvn"] = $vp["hvn"] ?? [];
                $zonas["lvn"] = $vp["lvn"] ?? [];
            }
        } catch (\Throwable $e) {}

        return $zonas;
    }

    /**
     * Persiste o OI atual e calcula a variação percentual em relação ao registro anterior.
     */
    private function calcularOiVariacao(string $symbol, string $exchange, float $oiAtual): float
    {
        try {
            // Buscar registro anterior antes de inserir o novo
            $anterior = OiHistorico::where('symbol', $symbol)
                ->where('exchange', $exchange)
                ->orderByDesc('created_at')
                ->first();

            // Persistir registro atual
            OiHistorico::create([
                'symbol'     => $symbol,
                'exchange'   => $exchange,
                'oi_valor'   => $oiAtual,
                'created_at' => now(),
            ]);

            // Calcular variação
            if ($anterior && $anterior->oi_valor > 0) {
                return round((($oiAtual - $anterior->oi_valor) / $anterior->oi_valor) * 100, 2);
            }

            return 0;
        } catch (\Throwable $e) {
            Log::error("GeminiAnalysis: Erro ao persistir/calcular OI", [
                'symbol'  => $symbol,
                'exchange' => $exchange,
                'error'   => $e->getMessage(),
            ]);
            return 0;
        }
    }

    /**
     * Verifica se a direção do setup conflita com o viés do score.
     */
    private function direcaoConflitante(string $direcaoSetup, string $scoreVies): bool
    {
        $direcaoSetup = strtoupper($direcaoSetup);
        $scoreVies = strtoupper($scoreVies);

        // Se score é NEUTRO, não há conflito
        if ($scoreVies === 'NEUTRO') {
            return false;
        }

        // LONG setup vs SHORT viés
        if ($direcaoSetup === 'LONG' && str_contains($scoreVies, 'SHORT')) {
            return true;
        }

        // SHORT setup vs LONG viés
        if ($direcaoSetup === 'SHORT' && str_contains($scoreVies, 'LONG')) {
            return true;
        }

        return false;
    }

    private function buildPrompt(
        string $symbol,
        string $timeframe,
        int    $leverage,
        string $contexto,
        float  $entryValue      = 0,
        array  $elementosVisuais = [],
        array  $macro            = [],
        int    $fearGreed        = 50,
        float  $btcDominancia    = 0,
        array  $wyckoffResult    = []
    ): string {
        $entryInfo = '';
        if ($entryValue > 0) {
            $valorTotal = $entryValue * $leverage;
            $entryInfo  = "\nVALOR DE ENTRADA: \${$entryValue} | Alavancagem: {$leverage}x | Total: $" . number_format($valorTotal, 2) . "\n";
        }

        $visuaisInfo = '';
        if (!empty($elementosVisuais['suportes'])) {
            $visuaisInfo .= "\nSUPORTES DESENHADOS: " . implode(', ', array_map(fn($s) => '$' . round($s, 6), $elementosVisuais['suportes'])) . "\n";
        }
        if (!empty($elementosVisuais['resistencias'])) {
            $visuaisInfo .= "RESISTENCIAS DESENHADAS: " . implode(', ', array_map(fn($r) => '$' . round($r, 6), $elementosVisuais['resistencias'])) . "\n";
        }
        if (!empty($elementosVisuais['padroes_graficos'])) {
            $visuaisInfo .= "PADROES GRAFICOS IDENTIFICADOS VIA OCR: " . implode(', ', $elementosVisuais['padroes_graficos']) . "\n";
            $visuaisInfo .= "INSTRUCAO: Citar padrao somente se confirmado por min 2 indicadores. Nunca inventar padrao nao listado.\n";
        }
        if (!empty($wyckoffResult['fase']) && $wyckoffResult['fase'] !== 'INDETERMINADO') {
            $visuaisInfo .= "WYCKOFF: Fase=" . $wyckoffResult['fase'] . " | Evento=" . ($wyckoffResult['evento'] ?? 'N/A') . " | Gatilho=" . ($wyckoffResult['gatilho'] ?? 'N/A') . "\n";
        }

        // Contexto macro real dos eventos persistidos (GeoEventService)
        $contextoMacroReal = '';
        try {
            $contextoMacroReal = app(\App\Services\GeoEventService::class)->getContextoMacroSemanal();
        } catch (\Throwable $e) {
            Log::warning('buildPrompt: falha ao buscar contexto macro', ['error' => $e->getMessage()]);
        }

        $macroInfo = '';
        if (!empty($macro['vix'])) {
            $macroInfo .= "VIX=" . $macro['vix'] . " | DXY=" . ($macro['dxy_variacao'] ?? 0) . "% | SP500=" . ($macro['sp500_variacao'] ?? 0) . "%\n";
        }
        if ($fearGreed > 0)     $macroInfo .= "FEAR & GREED: {$fearGreed}/100\n";
        if ($btcDominancia > 0) $macroInfo .= "BTC DOMINANCIA: {$btcDominancia}%\n";
        if (!empty($contextoMacroReal)) $macroInfo .= "\n" . $contextoMacroReal;

        $macroInfo .= "\n=== REGRAS CRITICAS — SEPARACAO DE CAMPOS (IMUTAVEL) ===\n";
        $macroInfo .= "\nCAMPO macroGeopolitica.resumo — ESCREVER APENAS:\n";
        $macroInfo .= "  Fed, BCE, BoJ, PBoC — decisoes de juros, inflacao, dados macro.\n";
        $macroInfo .= "  Eventos geopoliticos com impacto global (guerras, tarifas, sancoes).\n";
        $macroInfo .= "  Calendario economico desta semana: se ja divulgado informar resultado,\n";
        $macroInfo .= "  se previsto informar data e dado esperado.\n";
        $macroInfo .= "  PROIBIDO neste campo: {$symbol}, Fear&Greed, derivativos do ativo.\n";
        $macroInfo .= "\nCAMPO dadosAtivo.narrativa — ESCREVER APENAS sobre {$symbol}:\n";
        $macroInfo .= "  Movimentacao de whales, hacks, parcerias, listagens, desenvolvimento,\n";
        $macroInfo .= "  seguranca do protocolo, narrativa da comunidade sobre o projeto.\n";
        $macroInfo .= "  PROIBIDO neste campo: Fed, BCE, CPI, NFP, juros, guerras, macro.\n";
        $macroInfo .= "VIOLACAO DESSAS REGRAS INVALIDA A ANALISE.\n";

        $instrucaoNarrativa = "
INSTRUCAO DE NARRATIVA (campo analiseTecnica):
Escrever como trader profissional ao vivo. SEMPRE citar valores numericos reais dos indicadores.
Estrutura bearish (preco abaixo das 3 EMAs declinando + BOS de baixa) PREVALECE sobre RSI em sobrevenda.
RSI em sobrevenda em tendencia de baixa = risco de repique, nao reversao confirmada.
NUNCA usar travessao. NUNCA dizer limite inferior, limite superior, resistencia superior, suporte inferior.
NUNCA inventar padroes graficos nao listados acima.
Se triangulo: usar LTA ou LTB. Se canal: usar base do canal ou topo do canal.
";

        return "Voce e um trader profissional de derivativos de criptomoedas com 15 anos de experiencia. Esta analisando o par {$symbol} no timeframe {$timeframe}.\n\n"
            . "HIERARQUIA DE DADOS: Os dados abaixo foram calculados matematicamente via API com candles brutos e sao a verdade absoluta. Em caso de conflito entre estes dados e a imagem do grafico, estes dados prevalecem sempre.\n\n"
            . $contexto
            . "\nALAVANCAGEM SELECIONADA: {$leverage}x\n"
            . $entryInfo
            . $visuaisInfo
            . $macroInfo
            . $instrucaoNarrativa
            . "\nRetorne APENAS o JSON com esta estrutura exata (sem markdown, sem ```):\n"
            . '{"direcaoProvavel":"LONG ou SHORT","scoreProbabilidade":72,"confianca":65,"regime":"BULLISH ou BEARISH ou NEUTRO","entradaSugerida":{"planoA":0,"planoB":0,"descricaoPlanoA":"","descricaoPlanoB":""},"execucao":{"acao":"LONG","motivo":"","setup":{"entrada":0,"stop":0,"tp1":0,"tp2":0,"tp3":0,"alavancagem":5,"liquidacao":0,"riscoPct":2.0,"rr1":1.5,"verificacao":"SEGURO"}},"analiseTecnica":"analise completa em formato trader","macroGeopolitica":{"resumo":"resumo real dos dados macro","eventos":[""]},"dadosAtivo":{"narrativa":"dados exclusivos do ativo analisado","gatilhosPositivos":[],"gatilhosNegativos":[]},"zonaInteresse":{"tipo":"PULLBACK","zona":"","invalidacao":""}}';
    }

    private function callGemini(string $imageBase64, string $prompt): array
    {
        $apiKey = config("services.gemini_key");
        $model = config("services.gemini_analysis_model", "gemini-2.5-flash");

        $payload = [
            "contents" => [[
                "parts" => [
                    ["text" => $prompt],
                    ["inline_data" => ["mime_type" => "image/png", "data" => $imageBase64]],
                ],
            ]],
            "generationConfig" => [
                "temperature" => 0,
                "maxOutputTokens" => 8192,
                "responseMimeType" => "application/json",
            ],
        ];

        $response = Http::timeout(120)->post(
            "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$apiKey}",
            $payload
        );

        if (!$response->successful()) {
            Log::error("Gemini API error", ["status" => $response->status(), "body" => $response->body()]);
            throw new \RuntimeException("Gemini API error: {$response->status()}");
        }

        $rawText = $response->json()["candidates"][0]["content"]["parts"][0]["text"] ?? null;
        if (!$rawText) throw new \RuntimeException("Gemini retornou resposta vazia");

        $jsonText = trim($rawText);
        // Remove markdown code fences (```json ... ``` or ``` ... ```)
        $jsonText = preg_replace("/^```(?:json)?\s*\n?/m", "", $jsonText);
        $jsonText = preg_replace("/\n?\s*```\s*$/m", "", $jsonText);
        $jsonText = trim($jsonText);

        // Try to extract JSON object/array if there's surrounding text
        if (!str_starts_with($jsonText, '{') && !str_starts_with($jsonText, '[')) {
            if (preg_match('/(\{[\s\S]*\})/m', $jsonText, $matches)) {
                $jsonText = $matches[1];
            } elseif (preg_match('/(\[[\s\S]*\])/m', $jsonText, $matches)) {
                $jsonText = $matches[1];
            }
        }

        $parsed = json_decode($jsonText, true);
        if (!$parsed) {
            // Try fixing common issues: trailing commas, control characters
            $jsonText = preg_replace('/,\s*([\]}])/m', '$1', $jsonText);
            $jsonText = preg_replace('/[\x00-\x1F\x7F]/u', '', $jsonText);
            $parsed = json_decode($jsonText, true);
        }
        if (!$parsed) {
            Log::error("Falha ao parsear JSON do Gemini", ["rawText" => $rawText, "jsonText" => $jsonText]);
            throw new \RuntimeException("Falha ao parsear JSON do Gemini");
        }

        return $parsed;
    }

    private function buildTradeSetup(array $gemini, array $indicadores, array $score, array $zonas, array $macro, array $derivativos, array $multiTimeframe, string $symbol, string $timeframe, int $leverage, array $candles): array
    {
        $result = $gemini;
        $result["pair"] = $symbol;

        // Override indicadores com valores reais
        if (!empty($indicadores["rsi"])) $result["indicadores"]["rsi"] = $indicadores["rsi"];
        if (!empty($indicadores["adx"])) $result["indicadores"]["adx"] = $indicadores["adx"];
        if (!empty($indicadores["plus_di"])) $result["indicadores"]["plusDI"] = $indicadores["plus_di"];
        if (!empty($indicadores["minus_di"])) $result["indicadores"]["minusDI"] = $indicadores["minus_di"];
        if (!empty($indicadores["macd_histograma"])) $result["indicadores"]["macdHist"] = $indicadores["macd_histograma"];
        if (!empty($indicadores["ema21"])) $result["indicadores"]["ema21"] = $indicadores["ema21"];
        if (!empty($indicadores["ema50"])) $result["indicadores"]["ema50"] = $indicadores["ema50"];
        if (!empty($indicadores["ema200"])) $result["indicadores"]["ema200"] = $indicadores["ema200"];
        if (!empty($indicadores["atr"])) $result["indicadores"]["atr"] = $indicadores["atr"];
        if (!empty($derivativos["cvd"]["delta"])) $result["indicadores"]["cvd"] = $derivativos["cvd"]["delta"];

        // Fontes (do TechnicalAnalysisService com fallback OCR)
        $result["indicadores"]["fontes"] = $indicadores["fontes"] ?? [
            "rsi" => "INDISPONIVEL", "adx" => "INDISPONIVEL", "atr" => "INDISPONIVEL", "ema21" => "INDISPONIVEL", "ema50" => "INDISPONIVEL", "ema200" => "INDISPONIVEL",
        ];

        // Compressao
        if (!empty($indicadores["compressao"])) {
            $result["indicadores"]["compressaoDetectada"] = $indicadores["compressao"]["detectada"];
            $result["indicadores"]["nivelCompressao"] = $indicadores["compressao"]["nivel"];
        }

        // Divergencia RSI
        if (!empty($indicadores["divergencia_rsi"])) {
            $result["indicadores"]["divergenciaRSI"] = $indicadores["divergencia_rsi"];
        }

        // Bollinger
        if (!empty($indicadores["bollinger"])) {
            $result["indicadores"]["bollinger"] = $indicadores["bollinger"];
        }

        // Score detalhado com flags visuais e sintese
        $flagLabels = [
            "GOLDEN_CROSS" => "Golden Cross EMA50/200",
            "DEATH_CROSS" => "Death Cross EMA50/200",
            "RSI_SOBRECOMPRA" => "RSI em zona de sobrecompra",
            "RSI_SOBREVENDA" => "RSI em zona de sobrevenda",
            "TENDENCIA_FORTE" => "ADX indica tendencia forte",
            "COMPRESSAO_VOLATILIDADE" => "Compressao de volatilidade detectada",
            "FUNDING_ALTO" => "Funding rate elevado",
            "FUNDING_NEGATIVO" => "Funding rate negativo",
            "OI_ALTA_PRECO_ALTA" => "OI subindo com preco (tendencia forte)",
            "OI_QUEDA" => "Open Interest em queda",
            "RANGING_SEM_TENDENCIA" => "Mercado sem tendencia definida",
            "ROMPIMENTO_IMINENTE" => "Rompimento iminente (compressao severa)",
            "PRESSAO_COMPRADORA_BOOK" => "Pressao compradora no orderbook",
            "PRESSAO_VENDEDORA_BOOK" => "Pressao vendedora no orderbook",
            "CVD_DIVERGENCIA_BEARISH" => "Divergencia CVD bearish",
            "CVD_DIVERGENCIA_BULLISH" => "Divergencia CVD bullish",
            "LONG_SQUEEZE_IMINENTE" => "Long squeeze iminente",
            "SHORT_SQUEEZE_IMINENTE" => "Short squeeze iminente",
            "RALLY_FRACO" => "Rally sem suporte de OI",
            "CORRECAO_FRACA" => "Correcao sem liquidacao de OI",
            "MERCADO_SOBRECOMPRADO" => "Mercado sobrecomprado (L/S ratio)",
            "MERCADO_SOBREVENDIDO" => "Mercado sobrevendido (L/S ratio)",
            "VIX_ELEVADO" => "VIX elevado (incerteza)",
            "VIX_CRITICO" => "VIX critico (medo extremo)",
            "DXY_FORTE" => "Dolar forte pressionando cripto",
            "SAIDA_DO_MERCADO" => "Saida de capital (USDT dominancia)",
            "ACUMULACAO_INSTITUCIONAL" => "Acumulacao institucional detectada",
            "DISTRIBUICAO_INSTITUCIONAL" => "Distribuicao institucional detectada",
            "EUFORIA_EXTREMA" => "Euforia extrema (Fear and Greed)",
            "CAUTELA_EUFORIA" => "Cautela em zona de euforia",
            "PANICO_EXTREMO_OPORTUNIDADE" => "Panico extremo (oportunidade)",
            "CLUSTER_ACIMA" => "Cluster de liquidacao acima do preco",
            "CLUSTER_ABAIXO" => "Cluster de liquidacao abaixo do preco",
            "DESCORRELACAO_BTC" => "Descorrelacao com BTC detectada",
        ];

        $score["flagsVisuais"] = array_map(function ($flag) use ($flagLabels) {
            return $flagLabels[$flag] ?? $flag;
        }, $score["flags"] ?? []);

        $score["sintese"] = "Score {$score["scoreFinal"]}/100 | Vies: {$score["vies"]} | Confiabilidade: {$score["confiabilidade"]} | " . count($score["flags"] ?? []) . " flags ativas";

        $result["scoreDetalhado"] = $score;

        // Multi-timeframe
        $result["multiTimeframe"] = $multiTimeframe;

        // Zonas estruturais
        $result["zonasEstruturais"] = $zonas;

        // Macro
        $result["macroData"] = $macro;

        // Dados de mercado detalhados
        $precoAtual = $indicadores["preco"] ?? 0;
        $atrValor = $indicadores["atr"] ?? 0;
        $result["dados_mercado"] = [
            "funding_rate" => $derivativos["funding_rate"] ?? "0",
            "cvd" => $derivativos["cvd"] ?? ["delta" => 0, "imbalance" => 0],
            "open_interest" => $derivativos["oi"] ?? 0,
            "long_short_ratio" => $derivativos["long_short_ratio"] ?? 50,
            "atr" => [
                "value" => $atrValor,
                "percent" => $precoAtual > 0 ? round(($atrValor / $precoAtual) * 100, 4) : 0,
                "fonte" => !empty($atrValor) ? "API" : "INDISPONIVEL",
            ],
        ];

        // Multiplicador de sessao
        $utcHour = (int) gmdate("G");
        $sessionMultiplier = 1.0;
        if ($utcHour >= 0 && $utcHour < 8) { $sessionMultiplier = 0.85; $result['sessao'] = ['nome' => 'Sessão Ásia', 'cor' => 'text-yellow-500']; }
        elseif ($utcHour >= 8 && $utcHour < 13) { $sessionMultiplier = 0.95; $result['sessao'] = ['nome' => 'Sessão Londres', 'cor' => 'text-blue-500']; }
        elseif ($utcHour >= 13 && $utcHour < 21) { $sessionMultiplier = 1.0; $result['sessao'] = ['nome' => 'Sessão NY', 'cor' => 'text-green-500']; }
        else { $sessionMultiplier = 0.90; $result['sessao'] = ['nome' => 'Overnight', 'cor' => 'text-gray-500']; }

        if (!empty($result["scoreProbabilidade"])) {
            $result["scoreProbabilidade"] = round($result["scoreProbabilidade"] * $sessionMultiplier);
        }

        // Wyckoff — agora calculado no analisar() e passado via result
        // (migrado de detecção primitiva para nova assinatura completa)

        // Fallback macroGeopolitica
        if (empty($result['macroGeopolitica'])) {
            $eventos = [];
            if (!empty($macro['vix']) && $macro['vix'] > 25) $eventos[] = "VIX elevado ({$macro['vix']}) — incerteza global alta";
            if (!empty($macro['dxy_variacao']) && abs($macro['dxy_variacao']) > 0.5) {
                $dir = $macro['dxy_variacao'] > 0 ? 'forte' : 'enfraquecendo';
                $eventos[] = "DXY {$dir} ({$macro['dxy_variacao']}%) — impacto direto em cripto";
            }
            if (!empty($macro['sp500_variacao']) && abs($macro['sp500_variacao']) > 1) {
                $dir = $macro['sp500_variacao'] > 0 ? 'positivo' : 'negativo';
                $eventos[] = "S&P500 {$dir} ({$macro['sp500_variacao']}%) — correlação com cripto";
            }
            $result['macroGeopolitica'] = [
                'resumo' => "VIX: " . ($macro['vix'] ?? 'N/A') . " | DXY: " . ($macro['dxy_variacao'] ?? 0) . "% | S&P500: " . ($macro['sp500_variacao'] ?? 0) . "%",
                'eventos' => $eventos,
            ];
        }

        // Fallback sentimentoNarrativa
        if (empty($result['sentimentoNarrativa'])) {
            $gatilhosPos = [];
            $gatilhosNeg = [];
            $positivos = ['PANICO_EXTREMO_OPORTUNIDADE', 'ACUMULACAO_INSTITUCIONAL', 'OI_ALTA_PRECO_ALTA'];
            $negativos = ['EUFORIA_EXTREMA', 'LONG_SQUEEZE_IMINENTE', 'VIX_CRITICO', 'SAIDA_DO_MERCADO'];
            foreach ($score['flags'] ?? [] as $flag) {
                if (in_array($flag, $positivos)) $gatilhosPos[] = $flagLabels[$flag] ?? $flag;
                if (in_array($flag, $negativos)) $gatilhosNeg[] = $flagLabels[$flag] ?? $flag;
            }
            $result['sentimentoNarrativa'] = [
                'score' => 50,
                'sentimento' => 'NEUTRO',
                'narrativa' => $score['sintese'] ?? '',
                'gatilhosPositivos' => $gatilhosPos,
                'gatilhosNegativos' => $gatilhosNeg,
            ];
        }

        // ZonaInteresse
        $result['zonaInteresse'] = $result['zonaInteresse'] ?? null;

        return $result;
    }

    private function extrairElementosVisuais(string $imageBase64): array
    {
        $cacheKey = "gemini:visuais:" . md5(substr($imageBase64, 0, 500));
        $cached = CacheManager::get($cacheKey);
        if ($cached) return $cached;

        $apiKey = config("services.gemini_key");
        $model = config("services.gemini_analysis_model", "gemini-2.5-flash");

        $prompt = 'Voce e um scanner visual especializado em graficos de trading. '
            . 'Extraia APENAS elementos visiveis claramente identificaveis. Retorne JSON puro (sem texto adicional): '
            . '{"suportes":[float],"resistencias":[float],'
            . '"linhas_tendencia":[{"tipo":"LTA|LTB|HORIZONTAL","pontos":[[x1,y1],[x2,y2]]}],'
            . '"fibonacci":[float],'
            . '"padroes_graficos":["string"],'
            . '"poc":float_ou_null,'
            . '"hvn":[float],'
            . '"lvn":[float],'
            . '"exchange":"binance|bybit|bitget|okx|null"}'
            . ' INSTRUCOES:'
            . ' poc: nivel de preco com maior volume no VRVP/Volume Profile visivel. null se nao houver.'
            . ' hvn: niveis com barras LARGAS no VRVP (High Volume Nodes). [] se nao houver.'
            . ' lvn: niveis com barras ESTREITAS no VRVP (Low Volume Nodes). [] se nao houver.'
            . ' exchange: logo visivel no grafico (binance, bybit, bitget, okx).'
            . ' padroes_graficos: apenas padroes CLARAMENTE formados. Nomes validos: TRIANGULO_ASCENDENTE, TRIANGULO_DESCENDENTE, TRIANGULO_SIMETRICO, BANDEIRA_ALTA, BANDEIRA_BAIXA, CUNHA_ASCENDENTE, CUNHA_DESCENDENTE, OCO, OCO_INVERTIDO, TOPO_DUPLO, FUNDO_DUPLO, CANAL_ALTA, CANAL_BAIXA. NUNCA inventar.'
            . ' PROIBIDO: hifens, resistencia superior, suporte inferior, inventar valores.';

        $payload = [
            "contents" => [["parts" => [
                ["text" => $prompt],
                ["inline_data" => ["mime_type" => "image/png", "data" => $imageBase64]],
            ]]],
            "generationConfig" => ["temperature" => 0, "responseMimeType" => "application/json"],
        ];

        try {
            $response = Http::timeout(30)->post(
                "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$apiKey}",
                $payload
            );

            if (!$response->successful()) return [];

            $rawText = $response->json()["candidates"][0]["content"]["parts"][0]["text"] ?? null;
            if (!$rawText) return [];

            $jsonText = trim($rawText);
            $jsonText = preg_replace("/^```json\s*/m", "", $jsonText);
            $jsonText = preg_replace("/^```\s*/m", "", $jsonText);
            $jsonText = preg_replace("/\s*```$/m", "", $jsonText);

            $parsed = json_decode($jsonText, true);
            if (!is_array($parsed)) return [];

            $parsed['suportes'] = array_values(array_filter(array_map('floatval', $parsed['suportes'] ?? [])));
            $parsed['resistencias'] = array_values(array_filter(array_map('floatval', $parsed['resistencias'] ?? [])));
            $parsed['padroes_graficos'] = array_values(array_filter($parsed['padroes_graficos'] ?? [], 'is_string'));
            $parsed['indicadores_visiveis'] = array_values(array_filter($parsed['indicadores_visiveis'] ?? [], 'is_string'));
            $parsed['poc'] = !empty($parsed['poc']) ? (float) $parsed['poc'] : null;
            $parsed['hvn'] = !empty($parsed['hvn']) ? array_map('floatval', $parsed['hvn']) : [];
            $parsed['lvn'] = !empty($parsed['lvn']) ? array_map('floatval', $parsed['lvn']) : [];
            $parsed['exchange'] = !empty($parsed['exchange']) && is_string($parsed['exchange']) ? $parsed['exchange'] : null;

            CacheManager::put($cacheKey, $parsed, 300);
            return $parsed;
        } catch (\Throwable $e) {
            Log::warning("GeminiAnalysis: Erro OCR visual", ["error" => $e->getMessage()]);
            return [];
        }
    }

    private function gerarNarrativa(
        string $symbol,
        array  $indicadores,
        array  $score,
        array  $execucao,
        array  $wyckoff          = [],
        array  $derivativos      = [],
        array  $elementosVisuais = []
    ): array {
        $apiKey  = config('services.gemini_key');
        $model   = config('services.gemini_analysis_model', 'gemini-2.5-flash');
        $setup   = $execucao['setup'] ?? [];
        $preco   = $indicadores['preco'] ?? 'N/A';
        $direcao = $execucao['acao']     ?? 'N/A';

        $padroes    = $elementosVisuais['padroes_graficos'] ?? [];
        $padroesStr = !empty($padroes) ? implode(', ', $padroes) : 'nenhum detectado';
        $fundingStr = $derivativos['funding_rate']         ?? 'N/A';
        $cvdStr     = $derivativos['cvd']['delta']         ?? 'N/A';
        $lsStr      = $derivativos['long_short_ratio']     ?? 'N/A';
        $oiStr      = $derivativos['oi_variacao']          ?? 0;

        $wyckoffStr = '';
        if (!empty($wyckoff['fase']) && $wyckoff['fase'] !== 'INDETERMINADO') {
            $wyckoffStr = 'Fase Wyckoff: ' . $wyckoff['fase'] . '. Gatilho: ' . ($wyckoff['gatilho'] ?? '') . '.';
        }

        // PROMPT 1 — analiseTecnica (analise completa de trader)
        $prompt1 = "Voce e Genesis, analista quantitativo de derivativos cripto.\n"
            . "Ativo: {$symbol} | Preco: {$preco} | Direcao: {$direcao}\n"
            . "Score: " . ($score['scoreFinal'] ?? 0) . "/100 | Flags: " . implode(', ', $score['flags'] ?? []) . "\n"
            . "Setup: " . json_encode($setup) . "\n"
            . "Padroes graficos OCR: {$padroesStr}\n"
            . "Derivativos: Funding={$fundingStr} | CVD={$cvdStr} | L/S={$lsStr} | OI var={$oiStr}%\n"
            . "{$wyckoffStr}\n\n"
            . "FORMATO OBRIGATORIO (campo analiseTecnica):\n"
            . "Linha 1: estrutura do ativo — padrao grafico com nome tecnico (LTA/LTB nao limite) OU posicao nas EMAs.\n"
            . "Linha 2: RSI [valor] + ADX [valor] com +DI [valor] e -DI [valor] + leitura conjunta.\n"
            . "Linha 3: MACD — posicao em relacao ao zero + histograma expandindo ou contraindo.\n"
            . "Linha 4: Volume — tendencia + confirma ou contradiz o movimento.\n"
            . "Linha 5: CVD direcao + VRVP posicao (POC valor, HVN ou LVN proximo).\n"
            . "Linha 6 (se Fibonacci): nivel atual + contexto da retracao + o que confirma ou invalida.\n"
            . "Linha 7 (se Wyckoff): fase e gatilho operacional.\n"
            . "Linha 8: confluencia principal OU contradicao relevante que exige cautela.\n"
            . "Linha 9: invalidacao da tese — evento tecnico especifico que invalida o setup.\n\n"
            . "REGRAS ABSOLUTAS:\n"
            . "NUNCA usar travessao.\n"
            . "NUNCA dizer limite inferior, limite superior, resistencia superior, suporte inferior.\n"
            . "NUNCA inventar padrao nao detectado via OCR.\n"
            . "SEMPRE citar valores numericos reais — nunca dizer apenas alto ou baixo.\n"
            . "Se houver contradicao entre indicadores, mencionar explicitamente.";

        // PROMPT 2 — rationalScore (justificativa do score — max 3 linhas)
        $sf = $score['scoreFinal']                  ?? 0;
        $pt = $score['blocoTecnico']['percentual']   ?? 0;
        $pd = $score['blocoDerivativos']['percentual'] ?? 0;
        $fl = implode(', ', $score['flags']          ?? []);
        $vi = $score['vies']                         ?? '';
        $co = $score['confiabilidade']               ?? '';

        $prompt2 = "Score: {$sf}/100. Tecnico: {$pt}%. Derivativos: {$pd}%. Flags: {$fl}. Vies: {$vi}. Confiabilidade: {$co}."
            . " Explique em 2 a 3 linhas por que o score resultou nesse numero."
            . " O que pesou positivo e negativo nos blocos."
            . " Citar as flags mais relevantes."
            . " Nunca repetir a analise tecnica. Nunca usar travessao.";

        $analiseTecnica = '';
        $rationalScore  = '';

        try {
            $r1 = Http::timeout(30)->post(
                "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$apiKey}",
                [
                    'contents'         => [['parts' => [['text' => $prompt1]]]],
                    'generationConfig' => ['temperature' => 0.3, 'maxOutputTokens' => 1024],
                ]
            );
            if ($r1->successful()) {
                $analiseTecnica = $r1->json()['candidates'][0]['content']['parts'][0]['text'] ?? '';
            }
        } catch (\Throwable $e) {
            Log::warning('gerarNarrativa analiseTecnica: ' . $e->getMessage());
        }

        try {
            $r2 = Http::timeout(15)->post(
                "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$apiKey}",
                [
                    'contents'         => [['parts' => [['text' => $prompt2]]]],
                    'generationConfig' => ['temperature' => 0, 'maxOutputTokens' => 256],
                ]
            );
            if ($r2->successful()) {
                $rationalScore = $r2->json()['candidates'][0]['content']['parts'][0]['text'] ?? '';
            }
        } catch (\Throwable $e) {
            Log::warning('gerarNarrativa rationalScore: ' . $e->getMessage());
        }

        return [
            'analiseTecnica' => $analiseTecnica,
            'rationalScore'  => $rationalScore,
        ];
    }

    // ════════════════════════════════════════════════════════════════════════
    // C-02: Métodos dinâmicos para geopolitica_score e sentimento_moeda_score
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Calcula score geopolítico a partir dos eventos persistidos pelo GeoEventService.
     * Range: -5 a +5. Positivo = contexto bullish, negativo = bearish.
     */
    private function calcularGeopoliticaScore(): int
    {
        try {
            $eventos = \App\Models\GeoEvent::where('created_at', '>=', now()->subDays(7))
                ->orderByDesc('created_at')
                ->limit(10)
                ->get();

            $score = 0;
            foreach ($eventos as $e) {
                if (in_array($e->bias, ['RISK_ON', 'BULLISH'])) $score += 1;
                elseif (in_array($e->bias, ['RISK_OFF', 'BEARISH', 'SUPPLY_SHOCK', 'INFLATIONARY'])) $score -= 1;
            }
            return max(-5, min(5, $score));
        } catch (\Throwable $e) {
            Log::debug('calcularGeopoliticaScore: falha', ['error' => $e->getMessage()]);
            return 0;
        }
    }

    /**
     * Calcula score de sentimento do ativo a partir de Fear & Greed,
     * dominância BTC e variação de OI.
     * Range: -5 a +5.
     */
    private function calcularSentimentoMoeda(int $fg, float $btcDom, array $deriv): int
    {
        $score = 0;

        // Fear & Greed
        if      ($fg < 20) $score -= 2;
        elseif  ($fg < 35) $score -= 1;
        elseif  ($fg > 80) $score += 2;
        elseif  ($fg > 65) $score += 1;

        // Dominância BTC alta = capital saindo de alts
        if      ($btcDom > 55) $score -= 1;
        elseif  ($btcDom < 45) $score += 1;

        // OI variação da moeda
        $oiVar = (float) ($deriv['oi_variacao'] ?? 0);
        if      ($oiVar > 5)  $score += 1;
        elseif  ($oiVar < -5) $score -= 1;

        return max(-5, min(5, $score));
    }

    /**
     * C-05 (helper): Retorna contexto macro semanal dos eventos persistidos.
     */
    private function getContextoMacroSemanal(): string
    {
        try {
            $eventos = \App\Models\GeoEvent::where('created_at', '>=', now()->subDays(7))
                ->orderByDesc('severity')
                ->limit(6)
                ->get();

            if ($eventos->isEmpty()) return '';

            $texto = "CONTEXTO MACRO E GEOPOLITICO (ultimos 7 dias):\n";
            foreach ($eventos as $e) {
                $texto .= "- [{$e->category}] {$e->title}: {$e->summary} (Impacto: {$e->bias})\n";
            }
            return $texto;
        } catch (\Throwable $e) {
            return '';
        }
    }

}
