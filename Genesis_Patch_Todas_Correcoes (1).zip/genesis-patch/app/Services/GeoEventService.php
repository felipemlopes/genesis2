<?php

namespace App\Services;

use App\Models\GeoEvent;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class GeoEventService
{
    /**
     * Region-to-coordinates mapping (same as frontend geopoliticalEngine.ts)
     */
    private const REGION_COORDINATES = [
        'MIDDLE_EAST'   => [29.2985, 42.5510],
        'EUROPE'        => [48.5260, 15.2551],
        'ASIA'          => [34.0479, 100.6197],
        'NORTH_AMERICA' => [37.0902, -95.7129],
        'SOUTH_AMERICA' => [-14.2350, -51.9253],
        'AFRICA'        => [1.0231, 18.7322],
        'RUSSIA'        => [61.5240, 105.3188],
        'CHINA'         => [35.8617, 104.1954],
    ];

    public function __construct(
        private TelegramService $telegram
    ) {}

    /**
     * Fetch geopolitical events from Gemini API, normalize, deduplicate, persist and notify.
     *
     * @return array<GeoEvent> Newly created GeoEvent models
     */
    public function fetchAndStore(): array
    {
        try {
            $rawEvents = $this->callGeminiApi();
        } catch (\Throwable $e) {
            Log::error('GeoEventService: Falha ao chamar Gemini API', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return [];
        }

        if (empty($rawEvents) || ! is_array($rawEvents)) {
            Log::debug('GeoEventService: Nenhum evento retornado pela Gemini API');

            return [];
        }

        $newEvents = [];

        foreach ($rawEvents as $raw) {
            if (empty($raw['title'])) {
                continue;
            }

            // Deduplication: case-insensitive title check
            $exists = GeoEvent::whereRaw('LOWER(title) = ?', [mb_strtolower(trim($raw['title']))])->exists();

            if ($exists) {
                Log::debug('GeoEventService: Evento duplicado ignorado', ['title' => $raw['title']]);

                continue;
            }

            // Normalize and persist
            $event = $this->normalizeAndCreate($raw);

            if ($event) {
                $newEvents[] = $event;

                // Send Telegram notification for each new event
                try {
                    $message = $this->formatTelegramMessage($event);
                    $this->telegram->sendMessage($message);
                } catch (\Throwable $e) {
                    Log::error('GeoEventService: Falha ao enviar Telegram', [
                        'event_id' => $event->id,
                        'error' => $e->getMessage(),
                    ]);
                }
            }
        }

        return $newEvents;
    }

    /**
     * Get events created in the last 10 minutes that the user has NOT been notified about.
     */
    public function getUnnotifiedForUser(int $userId): Collection
    {
        return GeoEvent::where('created_at', '>=', now()->subMinutes(10))
            ->whereDoesntHave('notifiedUsers', function ($query) use ($userId) {
                $query->where('user_id', $userId);
            })
            ->orderBy('created_at', 'desc')
            ->get();
    }

    /**
     * Mark events as notified for a given user by inserting into the pivot table.
     */
    public function markAsNotified(int $userId, array $eventIds): void
    {
        if (empty($eventIds)) {
            return;
        }

        $events = GeoEvent::whereIn('id', $eventIds)->get();

        foreach ($events as $event) {
            // Use syncWithoutDetaching to avoid duplicates, set notified_at
            $event->notifiedUsers()->syncWithoutDetaching([
                $userId => ['notified_at' => now()],
            ]);
        }
    }

    /**
     * Format a Telegram notification message for a GeoEvent.
     */
    private function formatTelegramMessage(GeoEvent $event): string
    {
        $severityEmoji = match ($event->severity) {
            'CRITICAL' => '🔴',
            'HIGH'     => '🟠',
            'MEDIUM'   => '🟡',
            'LOW'      => '🟢',
            default    => '⚪',
        };

        $lines = [];
        $lines[] = "{$severityEmoji} <b>{$event->title}</b>";
        $lines[] = '';
        $lines[] = "📍 <b>Localização:</b> {$event->location}";
        $lines[] = "⚠️ <b>Severidade:</b> {$event->severity}";
        $lines[] = "📊 <b>Viés de Mercado:</b> {$event->market_bias}";

        if ($event->us_market_impact) {
            $lines[] = "🇺🇸 <b>Impacto EUA:</b> {$event->us_market_impact}";
        }

        if ($event->crypto_impact) {
            $lines[] = "₿ <b>Impacto Crypto:</b> {$event->crypto_impact}";
        }

        return implode("\n", $lines);
    }

    /**
     * Call the Gemini API with google_search_retrieval tool.
     *
     * @return array Raw events from Gemini
     */
    private function callGeminiApi(): array
    {
        $apiKey = config('services.gemini_key');

        if (! $apiKey) {
            Log::error('GeoEventService: GEMINI_API_KEY não configurada');

            return [];
        }

        $prompt = 'Faca uma busca pelas noticias geopoliticas e macroeconomicas mais criticas e recentes (ultimas 24h) com impacto no mercado financeiro global e criptomoedas. Retorne exatamente 3 ou 4 eventos mais relevantes.

RETORNE ESTRITAMENTE EM FORMATO JSON UM ARRAY DE OBJETOS COM AS SEGUINTES PROPRIEDADES:
[
  {
    "title": "string",
    "summary": "string",
    "category": "WAR | ENERGY | SHIPPING | CENTRAL_BANK | SANCTIONS | SUPPLY_CHAIN | CYBER | ELECTION | CIVIL_UNREST | TRADE | MILITARY | DIPLOMACY | COMMODITIES",
    "region": "MIDDLE_EAST | EUROPE | ASIA | NORTH_AMERICA | SOUTH_AMERICA | AFRICA | RUSSIA | CHINA",
    "location": "string",
    "severity": "LOW | MEDIUM | HIGH | CRITICAL",
    "bias": "BULLISH | BEARISH | RISK_OFF | RISK_ON | INFLATIONARY | DEFLATIONARY | SUPPLY_SHOCK | NEUTRAL",
    "asset": "string",
    "impacted_assets": ["string"],
    "us_market_impact": "string",
    "crypto_impact": "string",
    "sourceUrl": "string"
  }
]

Retorne apenas o JSON, sem nenhum texto adicional.';

        $payload = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt],
                    ],
                ],
            ],
            'tools' => [
                ['google_search_retrieval' => new \stdClass()],
            ],
        ];

        $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={$apiKey}";

        $response = Http::timeout(60)->post($url, $payload);

        if (! $response->successful()) {
            Log::error('GeoEventService: Gemini API retornou erro', [
                'status' => $response->status(),
                'body' => $response->body(),
            ]);

            return [];
        }

        $rawText = $response->json('candidates.0.content.parts.0.text');

        if (! $rawText) {
            Log::error('GeoEventService: Gemini retornou resposta vazia');

            return [];
        }

        // Clean markdown code fences if present
        $jsonText = trim($rawText);
        $jsonText = preg_replace('/^```json\s*/m', '', $jsonText);
        $jsonText = preg_replace('/^```\s*/m', '', $jsonText);
        $jsonText = preg_replace('/\s*```$/m', '', $jsonText);

        $parsed = json_decode($jsonText, true);

        if (! is_array($parsed)) {
            Log::error('GeoEventService: Falha ao parsear JSON da Gemini', [
                'rawText' => $rawText,
            ]);

            return [];
        }

        return $parsed;
    }

    /**
     * Normalize raw event data and create a GeoEvent model.
     */
    private function normalizeAndCreate(array $raw): ?GeoEvent
    {
        try {
            $region = strtoupper(trim($raw['region'] ?? ''));
            $coordinates = $this->getCoordinatesForRegion($region);

            $severity = strtoupper(trim($raw['severity'] ?? 'MEDIUM'));
            $category = strtoupper(trim($raw['category'] ?? 'TRADE'));
            $bias = strtoupper(trim($raw['bias'] ?? 'NEUTRAL'));

            $marketWeight = $this->calculateMarketWeight($severity, $bias);
            $relevance = $this->calculateRelevance($category, $severity);

            $event = GeoEvent::create([
                'title'            => trim($raw['title']),
                'summary'          => trim($raw['summary'] ?? ''),
                'category'         => $category,
                'latitude'         => $coordinates[0],
                'longitude'        => $coordinates[1],
                'location'         => trim($raw['location'] ?? ''),
                'region'           => $region,
                'severity'         => $severity,
                'market_bias'      => $bias,
                'asset'            => trim($raw['asset'] ?? ''),
                'impacted_assets'  => $raw['impacted_assets'] ?? [],
                'us_market_impact' => $raw['us_market_impact'] ?? null,
                'crypto_impact'    => $raw['crypto_impact'] ?? null,
                'source_url'       => trim($raw['sourceUrl'] ?? ''),
                'market_weight'    => $marketWeight,
                'relevance'        => $relevance,
                'confidence'       => 0.85,
                'status'           => 'STABLE',
                'expires_at'       => now()->addMinutes(10),
            ]);

            return $event;
        } catch (\Throwable $e) {
            Log::error('GeoEventService: Falha ao normalizar/criar evento', [
                'title' => $raw['title'] ?? 'unknown',
                'error' => $e->getMessage(),
            ]);

            return null;
        }
    }

    /**
     * Get coordinates for a region (same mapping as frontend).
     *
     * @return array [latitude, longitude]
     */
    private function getCoordinatesForRegion(string $region): array
    {
        return self::REGION_COORDINATES[$region] ?? [0.0, 0.0];
    }

    /**
     * Calculate market weight (1-100) based on severity and bias.
     */
    private function calculateMarketWeight(string $severity, string $bias): int
    {
        $weight = 50;

        if ($severity === 'CRITICAL') {
            $weight += 40;
        } elseif ($severity === 'HIGH') {
            $weight += 25;
        }

        if ($bias !== 'NEUTRAL') {
            $weight += 10;
        }

        return min(100, $weight);
    }

    /**
     * Calculate relevance (1-10) based on category and severity.
     */
    private function calculateRelevance(string $category, string $severity): int
    {
        $rel = 5;

        $priorityCategories = ['WAR', 'ENERGY', 'CENTRAL_BANK', 'SANCTIONS'];

        if (in_array($category, $priorityCategories)) {
            $rel += 3;
        }

        if ($severity === 'CRITICAL' || $severity === 'HIGH') {
            $rel += 2;
        }

        return min(10, $rel);
    }

    /**
     * C-02/Macro: Retorna string de contexto macro/geopolítico dos últimos 7 dias
     * para injeção no prompt do Gemini via buildPrompt().
     */
    public function getContextoMacroSemanal(): string
    {
        try {
            $eventos = GeoEvent::where('created_at', '>=', now()->subDays(7))
                ->orderByDesc('severity')
                ->limit(6)
                ->get();

            if ($eventos->isEmpty()) {
                // Se não há eventos recentes, disparar busca
                $this->fetchAndStore();
                $eventos = GeoEvent::where('created_at', '>=', now()->subHours(6))
                    ->orderByDesc('severity')
                    ->limit(6)
                    ->get();
            }

            if ($eventos->isEmpty()) return '';

            $texto = "CONTEXTO MACRO E GEOPOLITICO (ultimos 7 dias):\n";
            foreach ($eventos as $e) {
                $texto .= "- [{$e->category}] {$e->title}: {$e->summary} (Impacto: {$e->bias})\n";
            }
            return $texto;
        } catch (\Throwable $e) {
            Log::warning('GeoEventService.getContextoMacroSemanal: falha', ['error' => $e->getMessage()]);
            return '';
        }
    }

}
