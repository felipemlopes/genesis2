<?php

namespace App\Console\Commands;

use App\Models\Alerta;
use App\Services\BinanceService;
use App\Services\TechnicalAnalysisService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

/**
 * VarreduraMicroRadarCommand
 *
 * Varre pares da Binance Futures via API, detecta anomalias usando
 * indicadores técnicos e de derivativos, e grava alertas com
 * tipo='OPORTUNIDADE' na tabela genesis_alertas quando score >= 65.
 *
 * Conecta-se ao fluxo existente:
 *   → RadarController::alertas()  lê tipo='OPORTUNIDADE' + score >= 65
 *   → RadarController::revelar()  debita créditos e revela ativo/corretora
 *   → IAGatewayController         executa análise completa (100 créditos)
 *
 * Scheduler: a cada 5 minutos (Kernel.php)
 *   $schedule->command(VarreduraMicroRadarCommand::class)->everyFiveMinutes();
 */
class VarreduraMicroRadarCommand extends Command
{
    protected $signature   = 'radar:varredura';
    protected $description = 'Varre pares Binance, detecta anomalias e grava alertas OPORTUNIDADE';

    // ── Configurações ────────────────────────────────────────────────────────

    /** Score mínimo para disparar alerta (múltiplo de 5) */
    private const SCORE_MINIMO = 65;

    /** Expiração do alerta em horas */
    private const EXPIRACAO_HORAS = 4;

    /** Quantos pares varrer por ciclo (não sobrecarregar a API) */
    private const PARES_POR_CICLO = 10;

    /** Cache key para controle do último par alertado (evitar consecutivo) */
    private const CACHE_ULTIMO_PAR = 'micro_radar:ultimo_par';

    /** Cache key para índice de rotação da lista de pares */
    private const CACHE_INDICE_ROTACAO = 'micro_radar:indice_rotacao';

    /**
     * Lista de pares monitorados — top 50 USDT perpetuais Binance por liquidez.
     * Dev: pode tornar isso configurável via tabela no futuro.
     */
    private const PARES = [
        'BTCUSDT',  'ETHUSDT',  'BNBUSDT',  'SOLUSDT',  'XRPUSDT',
        'DOGEUSDT', 'ADAUSDT',  'AVAXUSDT', 'LINKUSDT', 'DOTUSDT',
        'MATICUSDT','UNIUSDT',  'LTCUSDT',  'ATOMUSDT', 'NEARUSDT',
        'APTUSDT',  'ARBUSDT',  'OPUSDT',   'INJUSDT',  'SUIUSDT',
        'SEIUSDT',  'TIAUSDT',  'PYTHUSDT', 'JUPUSDT',  'WIFUSDT',
        'FETUSDT',  'RENDERUSDT','ARUSDT',  'STXUSDT',  'RUNEUSDT',
        'LDOUSDT',  'GRTUSDT',  'SANDUSDT', 'MANAUSDT', 'AXSUSDT',
        'GALAUSDT', 'APEUSDT',  'IMXUSDT',  'GMXUSDT',  'PENDLEUSDT',
        'EIGENUSDT','ENAUSDT',  'ETHFIUSDT','REZUSDT',  'ZETAUSDT',
        'ALTUSDT',  'DYMUSDT',  'STRKUSDT', 'BLASTUSDT','WUSDT',
    ];

    // ── Pontuação por anomalia ───────────────────────────────────────────────

    private const SCORES = [
        'SPIKE_VOLUME'       => 25,  // volume > 3x SMA20
        'FUNDING_EXTREMO'    => 20,  // |funding| > 0.03%
        'OI_SPIKE'           => 20,  // OI cresce > 5% vs último registro
        'CVD_DIVERGENCIA'    => 15,  // direção CVD contradiz preço
        'MOVIMENTO_BRUSCO'   => 15,  // variação > 1.5% no último candle
        'BOOK_IMBALANCE'     => 15,  // L/S ratio extremo (>0.65 ou <0.35)
        'LIQUIDACAO_CASCADE' => 20,  // 3 candles consecutivos mesma direção > 1.5% total
    ];

    public function __construct(
        private readonly BinanceService $binance,
        private readonly TechnicalAnalysisService $techAnalysis,
    ) {
        parent::__construct();
    }

    // ════════════════════════════════════════════════════════════════════════
    // ENTRY POINT
    // ════════════════════════════════════════════════════════════════════════

    public function handle(): int
    {
        $inicio = microtime(true);
        Log::info('MicroRadar: Início da varredura');

        // Limpar alertas expirados antes de varrer
        $this->limparAlertasExpirados();

        // Obter lote de pares para este ciclo (rotação)
        $pares = $this->obterParesDosCiclo();

        $alertasGerados = 0;

        foreach ($pares as $symbol) {
            try {
                $resultado = $this->analisarPar($symbol);

                if ($resultado !== null && $resultado['score'] >= self::SCORE_MINIMO) {
                    $this->gravarAlerta($symbol, $resultado);
                    $alertasGerados++;

                    // Guardar último par alertado para evitar consecutivo
                    Cache::put(self::CACHE_ULTIMO_PAR, $symbol, now()->addMinutes(30));

                    Log::info("MicroRadar: Alerta gerado", [
                        'symbol' => $symbol,
                        'score'  => $resultado['score'],
                        'direcao'=> $resultado['direcao'],
                        'motivos'=> array_column($resultado['motivos'], 'label'),
                    ]);
                }
            } catch (\Throwable $e) {
                Log::warning("MicroRadar: Erro ao analisar {$symbol}", [
                    'error' => $e->getMessage(),
                ]);
            }
        }

        $duracao = round(microtime(true) - $inicio, 2);
        Log::info("MicroRadar: Varredura concluída", [
            'pares_varridos'   => count($pares),
            'alertas_gerados'  => $alertasGerados,
            'duracao_segundos' => $duracao,
        ]);

        return self::SUCCESS;
    }

    // ════════════════════════════════════════════════════════════════════════
    // ANÁLISE DE PAR
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Analisa um par e retorna score + motivos, ou null se dados insuficientes.
     */
    private function analisarPar(string $symbol): ?array
    {
        // ── 1. Buscar candles 1h (200 períodos) ─────────────────────────────
        $candles = $this->binance->getCandles($symbol, '1h', 200);
        if (count($candles) < 50) return null;

        $closes  = array_map(fn($c) => (float) $c[4], $candles);
        $volumes = array_map(fn($c) => (float) $c[5], $candles);
        $highs   = array_map(fn($c) => (float) $c[2], $candles);
        $lows    = array_map(fn($c) => (float) $c[3], $candles);

        $precoAtual  = end($closes);
        $prevClose   = $closes[count($closes) - 2];
        $variacaoPct = $prevClose > 0 ? (($precoAtual - $prevClose) / $prevClose) * 100 : 0;

        // ── 2. Buscar derivativos ────────────────────────────────────────────
        $funding   = $this->buscarFunding($symbol);
        $oi        = $this->buscarOI($symbol);
        $lsRatio   = $this->buscarLSRatio($symbol);
        $cvdDelta  = $this->buscarCVD($symbol);

        // ── 3. Detectar anomalias ────────────────────────────────────────────
        $motivos    = [];
        $scoreBruto = 0;
        $direcoes   = [];

        // SPIKE_VOLUME
        $volAtual = end($volumes);
        $sma20vol = array_sum(array_slice($volumes, -21, 20)) / 20;
        if ($sma20vol > 0 && $volAtual > $sma20vol * 3.0) {
            $scoreBruto += self::SCORES['SPIKE_VOLUME'];
            $direcoes[] = $variacaoPct >= 0 ? 'BULLISH' : 'BEARISH';
            $motivos[]  = [
                'label' => 'SPIKE_VOLUME',
                'value' => round($volAtual / $sma20vol, 1) . 'x SMA20',
            ];
        }

        // MOVIMENTO_BRUSCO
        if (abs($variacaoPct) >= 1.5) {
            $scoreBruto += self::SCORES['MOVIMENTO_BRUSCO'];
            $direcoes[] = $variacaoPct >= 0 ? 'BULLISH' : 'BEARISH';
            $motivos[]  = [
                'label' => 'MOVIMENTO_BRUSCO',
                'value' => round($variacaoPct, 2) . '%',
            ];
        }

        // FUNDING_EXTREMO
        if ($funding !== null && abs($funding) > 0.0003) {
            $scoreBruto += self::SCORES['FUNDING_EXTREMO'];
            // Funding muito positivo = longs sobrecarregados = sinal BEARISH
            // Funding muito negativo = shorts sobrecarregados = sinal BULLISH
            $direcoes[] = $funding > 0 ? 'BEARISH' : 'BULLISH';
            $motivos[]  = [
                'label' => 'FUNDING_EXTREMO',
                'value' => round($funding * 100, 4) . '%',
            ];
        }

        // OI_SPIKE
        $oiAnterior = $this->buscarOIAnterior($symbol);
        if ($oi !== null && $oiAnterior !== null && $oiAnterior > 0) {
            $variacaoOI = (($oi - $oiAnterior) / $oiAnterior) * 100;
            if (abs($variacaoOI) >= 5.0) {
                $scoreBruto += self::SCORES['OI_SPIKE'];
                // OI subindo + preço subindo = BULLISH; OI subindo + preço caindo = BEARISH
                if ($variacaoOI > 0) {
                    $direcoes[] = $variacaoPct >= 0 ? 'BULLISH' : 'BEARISH';
                } else {
                    $direcoes[] = 'NEUTRO'; // OI caindo = fechamento de posição
                }
                $motivos[] = [
                    'label' => 'OI_SPIKE',
                    'value' => round($variacaoOI, 2) . '%',
                ];
            }
        }

        // Persistir OI atual para próxima comparação
        if ($oi !== null) {
            $this->persistirOI($symbol, $oi);
        }

        // CVD_DIVERGENCIA
        if ($cvdDelta !== null) {
            $precoDireção = $variacaoPct >= 0 ? 'UP' : 'DOWN';
            $cvdDirecao   = $cvdDelta >= 0 ? 'UP' : 'DOWN';
            if ($precoDireção !== $cvdDirecao) {
                $scoreBruto += self::SCORES['CVD_DIVERGENCIA'];
                // Preço sobe mas CVD cai = distribuição = BEARISH
                $direcoes[] = $precoDireção === 'UP' ? 'BEARISH' : 'BULLISH';
                $motivos[]  = [
                    'label' => 'CVD_DIVERGENCIA',
                    'value' => 'Preco ' . $precoDireção . ' / CVD ' . $cvdDirecao,
                ];
            }
        }

        // BOOK_IMBALANCE — via L/S ratio
        if ($lsRatio !== null) {
            if ($lsRatio > 0.65) {
                // Mercado overlong → sinalizador BEARISH
                $scoreBruto += self::SCORES['BOOK_IMBALANCE'];
                $direcoes[] = 'BEARISH';
                $motivos[]  = [
                    'label' => 'BOOK_IMBALANCE',
                    'value' => 'L/S=' . round($lsRatio, 3) . ' (overlong)',
                ];
            } elseif ($lsRatio < 0.35) {
                // Mercado overshort → sinalizador BULLISH
                $scoreBruto += self::SCORES['BOOK_IMBALANCE'];
                $direcoes[] = 'BULLISH';
                $motivos[]  = [
                    'label' => 'BOOK_IMBALANCE',
                    'value' => 'L/S=' . round($lsRatio, 3) . ' (overshort)',
                ];
            }
        }

        // LIQUIDACAO_CASCADE — 3 candles consecutivos mesma direção
        $cascade = $this->detectarLiquidacaoCascade($closes, $volumes);
        if ($cascade !== null) {
            $scoreBruto += self::SCORES['LIQUIDACAO_CASCADE'];
            $direcoes[] = $cascade['direcao'];
            $motivos[]  = [
                'label' => 'LIQUIDACAO_CASCADE',
                'value' => $cascade['variacao_total'] . '% em 3 candles',
            ];
        }

        // ── 4. Sem anomalias? Retorna null ───────────────────────────────────
        if (empty($motivos)) return null;

        // ── 5. Score final (arredondar para múltiplo de 5, máximo 100) ───────
        $scoreFinal = min(100, (int) (round($scoreBruto / 5) * 5));

        // ── 6. Direção dominante ─────────────────────────────────────────────
        $contBull = count(array_filter($direcoes, fn($d) => $d === 'BULLISH'));
        $contBear = count(array_filter($direcoes, fn($d) => $d === 'BEARISH'));
        $direcao  = $contBull > $contBear ? 'BULLISH' : ($contBear > $contBull ? 'BEARISH' : 'NEUTRO');

        return [
            'score'       => $scoreFinal,
            'direcao'     => $direcao,
            'motivos'     => $motivos,
            'preco_atual' => $precoAtual,
            'variacao_pct'=> round($variacaoPct, 4),
        ];
    }

    // ════════════════════════════════════════════════════════════════════════
    // DETECÇÃO DE ANOMALIAS AUXILIARES
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Detecta cascata de liquidação: 3 candles consecutivos na mesma direção
     * com variação total acima de 1.5% e volume acima da SMA20.
     */
    private function detectarLiquidacaoCascade(array $closes, array $volumes): ?array
    {
        $n = count($closes);
        if ($n < 4) return null;

        $c1 = $closes[$n - 4]; $c2 = $closes[$n - 3];
        $c3 = $closes[$n - 2]; $c4 = $closes[$n - 1];

        $v2 = $volumes[$n - 3];
        $v3 = $volumes[$n - 2];
        $v4 = $volumes[$n - 1];

        $smaVol = array_sum(array_slice($volumes, -24, 20)) / 20;

        $dir1 = $c2 > $c1; $dir2 = $c3 > $c2; $dir3 = $c4 > $c3;
        if ($dir1 !== $dir2 || $dir2 !== $dir3) return null;

        $varTotal = $c1 > 0 ? abs(($c4 - $c1) / $c1) * 100 : 0;
        $volMedio = ($v2 + $v3 + $v4) / 3;

        if ($varTotal < 1.5 || $volMedio < $smaVol) return null;

        return [
            'direcao'       => $dir1 ? 'BULLISH' : 'BEARISH',
            'variacao_total'=> round($varTotal, 2),
        ];
    }

    // ════════════════════════════════════════════════════════════════════════
    // BUSCA DE DERIVATIVOS
    // ════════════════════════════════════════════════════════════════════════

    private function buscarFunding(string $symbol): ?float
    {
        try {
            $data = $this->binance->getFundingRate($symbol);
            $val  = $data['lastFundingRate'] ?? $data['funding_rate'] ?? null;
            return $val !== null ? (float) $val : null;
        } catch (\Throwable) {
            return null;
        }
    }

    private function buscarOI(string $symbol): ?float
    {
        try {
            $data = $this->binance->getOpenInterest($symbol);
            $val  = $data['openInterest'] ?? $data['oi'] ?? null;
            return $val !== null ? (float) $val : null;
        } catch (\Throwable) {
            return null;
        }
    }

    private function buscarLSRatio(string $symbol): ?float
    {
        try {
            $data = $this->binance->getLongShortRatio($symbol, '1h', 1);
            $val  = is_array($data) ? ($data[0]['longShortRatio'] ?? null) : null;
            return $val !== null ? (float) $val : null;
        } catch (\Throwable) {
            return null;
        }
    }

    private function buscarCVD(string $symbol): ?float
    {
        try {
            $data = $this->binance->getCvd($symbol, 200);
            return isset($data['delta']) ? (float) $data['delta'] : null;
        } catch (\Throwable) {
            return null;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // OI HISTÓRICO — usa tabela oi_historico já existente no projeto
    // ════════════════════════════════════════════════════════════════════════

    private function buscarOIAnterior(string $symbol): ?float
    {
        $row = DB::table('oi_historico')
            ->where('symbol', $symbol)
            ->where('exchange', 'BINANCE')
            ->orderByDesc('created_at')
            ->first();

        return $row ? (float) $row->oi_valor : null;
    }

    private function persistirOI(string $symbol, float $oi): void
    {
        try {
            DB::table('oi_historico')->insert([
                'symbol'     => $symbol,
                'exchange'   => 'BINANCE',
                'oi_valor'   => $oi,
                'created_at' => now(),
            ]);
        } catch (\Throwable $e) {
            Log::warning("MicroRadar: Falha ao persistir OI {$symbol}", [
                'error' => $e->getMessage(),
            ]);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // CONTROLE DE ROTAÇÃO — nunca mesmo par consecutivo
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Retorna lote de pares para o ciclo atual em rotação,
     * excluindo o último par que gerou alerta.
     */
    private function obterParesDosCiclo(): array
    {
        $ultimoPar = Cache::get(self::CACHE_ULTIMO_PAR);
        $indice    = (int) Cache::get(self::CACHE_INDICE_ROTACAO, 0);

        $total  = count(self::PARES);
        $pares  = [];
        $count  = 0;

        for ($i = 0; $i < $total && $count < self::PARES_POR_CICLO; $i++) {
            $par = self::PARES[($indice + $i) % $total];
            if ($par !== $ultimoPar) {
                $pares[] = $par;
                $count++;
            }
        }

        // Avançar índice para próximo ciclo
        $novoIndice = ($indice + self::PARES_POR_CICLO) % $total;
        Cache::put(self::CACHE_INDICE_ROTACAO, $novoIndice, now()->addHours(24));

        return $pares;
    }

    // ════════════════════════════════════════════════════════════════════════
    // GRAVAÇÃO DO ALERTA
    // ════════════════════════════════════════════════════════════════════════

    private function gravarAlerta(string $symbol, array $resultado): void
    {
        // Evitar duplicata: se já existe alerta OPORTUNIDADE para este par
        // nas últimas 4 horas, não grava novamente
        $existente = Alerta::where('ativo', $symbol)
            ->where('tipo', 'OPORTUNIDADE')
            ->where('created_at', '>=', now()->subHours(4))
            ->exists();

        if ($existente) {
            Log::info("MicroRadar: Alerta duplicado ignorado para {$symbol}");
            return;
        }

        $urgencia = $resultado['score'] >= 80 ? 'ALTA' : ($resultado['score'] >= 70 ? 'MEDIA' : 'BAIXA');

        $motivos     = $resultado['motivos'];
        $labelsTexto = implode(', ', array_column($motivos, 'label'));

        Alerta::create([
            'ativo'        => $symbol,
            'tipo'         => 'OPORTUNIDADE',
            'mensagem'     => "Anomalia detectada ({$resultado['score']}/100): {$labelsTexto}",
            'direcao'      => $resultado['direcao'],
            'urgencia'     => $urgencia,
            'corretora'    => 'BINANCE',
            'timeframe'    => '1h',
            'preco_atual'  => $resultado['preco_atual'],
            'variacao_pct' => $resultado['variacao_pct'],
            'score'        => $resultado['score'],
            'motivos'      => $motivos,
            'expires_at'   => now()->addHours(self::EXPIRACAO_HORAS),
            'enviado_sse'  => false,
            'enviado_telegram' => false,
        ]);
    }

    // ════════════════════════════════════════════════════════════════════════
    // MANUTENÇÃO
    // ════════════════════════════════════════════════════════════════════════

    private function limparAlertasExpirados(): void
    {
        try {
            $deletados = Alerta::where('tipo', 'OPORTUNIDADE')
                ->where('expires_at', '<', now())
                ->delete();

            if ($deletados > 0) {
                Log::info("MicroRadar: {$deletados} alertas expirados removidos");
            }
        } catch (\Throwable $e) {
            Log::warning('MicroRadar: Falha ao limpar alertas expirados', [
                'error' => $e->getMessage(),
            ]);
        }
    }
}
