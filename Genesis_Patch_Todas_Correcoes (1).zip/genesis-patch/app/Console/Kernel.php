<?php

namespace App\Console;

use App\Console\Commands\FetchGeoEventsCommand;
use App\Console\Commands\MonitoramentoAlertasCommand;
use App\Console\Commands\RenewCredits;
use App\Console\Commands\VerifyStatus;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     */
    protected function schedule(Schedule $schedule): void
    {
        //$schedule->command(VerifyStatus::class)->dailyAt('00:00');
        $schedule->command(RenewCredits::class)->dailyAt('01:00');
        $schedule->command('carteira:monitorar-mae')->everyMinute();
        $schedule->command('carteira:monitoramento-alertas')->everyFiveMinutes();
        $schedule->command('analises:verificar-resultados')->everyFiveMinutes();
        $schedule->command(FetchGeoEventsCommand::class)->everyFiveMinutes();
        // C-MicroRadar: Varredura de anomalias Binance a cada 5 minutos
        $schedule->command(\App\Console\Commands\VarreduraMicroRadarCommand::class)->everyFiveMinutes();
    }

    /**
     * Register the commands for the application.
     */
    protected function commands(): void
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
